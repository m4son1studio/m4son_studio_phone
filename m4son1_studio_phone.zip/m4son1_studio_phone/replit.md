# M4SON1 Phone - iPhone 15 Pro Max Simulator

## Overview

This project is a web-based iPhone 15 Pro Max simulator that creates a realistic mobile phone interface. It's designed to provide an interactive phone experience with various apps and features, mimicking the look and feel of an actual iPhone. The application appears to be built for integration with external frameworks, possibly for gaming or virtual environments.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modular, component-based architecture built entirely with vanilla HTML, CSS, and JavaScript:

### Frontend Architecture
- **Pure Web Technologies**: Uses HTML5, CSS3, and vanilla JavaScript without any frameworks
- **Modular Design**: Separates concerns into distinct modules (UI, apps, framework integration)
- **Component-Based Structure**: Each app is implemented as a class extending a base app class
- **Responsive Design**: Styled to mimic iPhone 15 Pro Max dimensions and appearance

### Key Design Decisions
- **No Framework Dependency**: Chosen for simplicity and direct control over performance
- **Class-Based Architecture**: Provides clear structure and inheritance for app development
- **Event-Driven Communication**: Uses message passing for external framework integration

## Key Components

### 1. Phone Interface (`main.js`)
- **Purpose**: Core interface controller managing app navigation and phone state
- **Features**: Time updates, event handling, app switching, home navigation
- **Key Methods**: `openApp()`, `goHome()`, `updateTime()`

### 2. App Management System (`apps.js`)
- **Purpose**: Manages all phone applications and their lifecycle
- **Architecture**: Base class pattern with specialized app classes
- **Apps Included**: Phone, Messages, Contacts, Maps, Camera, Photos, Music, Weather, Banking, Email, Calendar, Notes, Clock, Calculator, Settings

### 3. Framework Integration (`framework.js`)
- **Purpose**: Handles communication with external frameworks
- **Communication**: Message-based API for receiving calls, notifications, and app data
- **Integration Points**: Phone open/close, app data updates, notifications, call handling

### 4. Visual Design (`style.css`, `apps.css`)
- **iPhone 15 Pro Max Styling**: Accurate dimensions (320x692px) and design elements
- **Dynamic Island**: Simulates the actual iPhone dynamic island feature
- **App-Specific Styling**: Consistent design patterns for all applications

## Data Flow

1. **Initialization**: Phone interface loads and initializes app manager
2. **User Interaction**: Click events trigger app opening or navigation
3. **App Management**: PhoneApps class manages app lifecycle and rendering
4. **Framework Communication**: Two-way message passing with external systems
5. **State Management**: Current app state tracked and maintained

## External Dependencies

### CSS Libraries
- **Font Awesome 6.0.0**: Icon library for UI elements
- **Feather Icons 4.28.0**: Additional icon set for interface elements

### Integration Points
- **External Framework**: Designed to receive data and commands from parent applications
- **Message API**: Supports phone calls, notifications, and app data synchronization

## Deployment Strategy

The application is designed as a web-based simulator that can be:

1. **Embedded**: Integrated into larger applications via iframe or direct inclusion
2. **Standalone**: Run independently in web browsers
3. **Framework Integration**: Connected to gaming engines or virtual environments

### Technical Requirements
- Modern web browser with ES6+ support
- CDN access for external icon libraries
- Message API support for framework communication

## Development Notes

- The application uses a clean, modular architecture that makes it easy to add new apps
- All styling follows iPhone design guidelines for authentic appearance
- The framework integration system is flexible and can adapt to various external systems
- Performance is optimized through efficient DOM manipulation and event handling