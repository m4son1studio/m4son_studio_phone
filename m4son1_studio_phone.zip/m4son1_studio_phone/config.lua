Config = {}

-- General Settings
Config.OpenKey = 'F1'
Config.EnableSounds = true
Config.EnableNotifications = true
Config.PhoneModel = 'iPhone 15 Pro Max'

-- Framework Settings
Config.Framework = 'auto' -- 'auto', 'esx', 'qbcore'

-- Database Settings
Config.Database = {
    UseOxMySQL = true,
    TablePrefix = 'phone_'
}

-- App Settings
Config.Apps = {
    ['phone'] = { enabled = true, name = 'Phone', icon = 'phone' },
    ['messages'] = { enabled = true, name = 'Messages', icon = 'message-circle' },
    ['contacts'] = { enabled = true, name = 'Contacts', icon = 'users' },
    ['maps'] = { enabled = true, name = 'Maps', icon = 'map' },
    ['camera'] = { enabled = true, name = 'Camera', icon = 'camera' },
    ['photos'] = { enabled = true, name = 'Photos', icon = 'image' },
    ['music'] = { enabled = true, name = 'Music', icon = 'music' },
    ['weather'] = { enabled = true, name = 'Weather', icon = 'cloud' },
    ['banking'] = { enabled = true, name = 'Banking', icon = 'credit-card' },
    ['email'] = { enabled = true, name = 'Email', icon = 'mail' },
    ['calendar'] = { enabled = true, name = 'Calendar', icon = 'calendar' },
    ['notes'] = { enabled = true, name = 'Notes', icon = 'edit-3' },
    ['clock'] = { enabled = true, name = 'Clock', icon = 'clock' },
    ['calculator'] = { enabled = true, name = 'Calculator', icon = 'calculator' },
    ['settings'] = { enabled = true, name = 'Settings', icon = 'settings' }
}

-- Notification Settings
Config.Notifications = {
    Position = 'top-right',
    Duration = 5000,
    MaxNotifications = 5
}

-- Animation Settings
Config.Animations = {
    OpenDuration = 500,
    CloseDuration = 300,
    AppTransition = 200
}

-- Phone Features
Config.Features = {
    GPS = true,
    Bluetooth = true,
    WiFi = true,
    Cellular = true,
    NFC = true,
    AirDrop = true,
    Siri = false -- Disabled for FiveM
}

-- Phone Colors and Models
Config.PhoneColors = {
    ['iphone_15_pro_max_black'] = {
        name = 'iPhone 15 Pro Max - Black Titanium',
        frameColor = '#1a1a1a',
        buttonColor = '#2a2a2a',
        price = 1200,
        rarity = 'legendary'
    },
    ['iphone_15_pro_max_white'] = {
        name = 'iPhone 15 Pro Max - White Titanium',
        frameColor = '#f5f5f5',
        buttonColor = '#e0e0e0',
        price = 1200,
        rarity = 'legendary'
    },
    ['iphone_15_pro_max_blue'] = {
        name = 'iPhone 15 Pro Max - Blue Titanium',
        frameColor = '#1e3a8a',
        buttonColor = '#3b82f6',
        price = 1200,
        rarity = 'legendary'
    },
    ['iphone_15_pro_max_natural'] = {
        name = 'iPhone 15 Pro Max - Natural Titanium',
        frameColor = '#8b7355',
        buttonColor = '#a0916b',
        price = 1200,
        rarity = 'legendary'
    },
    ['iphone_15_pro_black'] = {
        name = 'iPhone 15 Pro - Black Titanium',
        frameColor = '#1a1a1a',
        buttonColor = '#2a2a2a',
        price = 1000,
        rarity = 'epic'
    },
    ['iphone_15_pro_white'] = {
        name = 'iPhone 15 Pro - White Titanium',
        frameColor = '#f5f5f5',
        buttonColor = '#e0e0e0',
        price = 1000,
        rarity = 'epic'
    },
    ['iphone_15_pro_blue'] = {
        name = 'iPhone 15 Pro - Blue Titanium',
        frameColor = '#1e3a8a',
        buttonColor = '#3b82f6',
        price = 1000,
        rarity = 'epic'
    },
    ['iphone_15_pro_natural'] = {
        name = 'iPhone 15 Pro - Natural Titanium',
        frameColor = '#8b7355',
        buttonColor = '#a0916b',
        price = 1000,
        rarity = 'epic'
    },
    ['iphone_15_pink'] = {
        name = 'iPhone 15 - Pink',
        frameColor = '#f8bbd9',
        buttonColor = '#ec4899',
        price = 800,
        rarity = 'rare'
    },
    ['iphone_15_yellow'] = {
        name = 'iPhone 15 - Yellow',
        frameColor = '#fef08a',
        buttonColor = '#eab308',
        price = 800,
        rarity = 'rare'
    },
    ['iphone_15_green'] = {
        name = 'iPhone 15 - Green',
        frameColor = '#bbf7d0',
        buttonColor = '#22c55e',
        price = 800,
        rarity = 'rare'
    },
    ['iphone_15_blue'] = {
        name = 'iPhone 15 - Blue',
        frameColor = '#bfdbfe',
        buttonColor = '#3b82f6',
        price = 800,
        rarity = 'rare'
    },
    ['iphone_15_black'] = {
        name = 'iPhone 15 - Black',
        frameColor = '#1f2937',
        buttonColor = '#374151',
        price = 800,
        rarity = 'rare'
    }
}
