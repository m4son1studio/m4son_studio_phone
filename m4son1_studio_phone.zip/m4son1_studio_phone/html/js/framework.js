// Framework Integration
class PhoneFramework {
    constructor() {
        this.framework = null;
        this.playerData = null;
        this.initialized = false;
    }

    // Initialize framework connection
    init() {
        // Listen for messages from client
        window.addEventListener('message', (event) => {
            const { action, data } = event.data;
            this.handleMessage(action, data);
        });

        this.initialized = true;
        console.log('Phone Framework initialized');
    }

    // Handle messages from client
    handleMessage(action, data) {
        switch (action) {
            case 'openPhone':
                this.onPhoneOpen(data);
                break;
            case 'closePhone':
                this.onPhoneClose();
                break;
            case 'receiveAppData':
                this.onReceiveAppData(data);
                break;
            case 'receiveNotification':
                this.onReceiveNotification(data);
                break;
            case 'updateAppData':
                this.onUpdateAppData(data);
                break;
            case 'receiveCall':
                this.onReceiveCall(data);
                break;
            case 'callEnded':
                this.onCallEnded();
                break;
            case 'updatePhoneColors':
                this.onUpdatePhoneColors(data);
                break;
            default:
                console.warn('Unknown action:', action);
        }
    }

    // Phone opened
    onPhoneOpen(data) {
        this.playerData = data.playerData;
        this.framework = data.framework;
        
        // Update UI with player data
        this.updatePlayerInfo();
        
        // Show phone
        document.getElementById('phone-container').classList.add('active');
        
        console.log('Phone opened, framework:', this.framework);
    }

    // Phone closed
    onPhoneClose() {
        document.getElementById('phone-container').classList.remove('active');
        console.log('Phone closed');
    }

    // Receive app data
    onReceiveAppData(data) {
        const { app, data: appData } = data;
        
        if (window.PhoneApps && window.PhoneApps[app]) {
            window.PhoneApps[app].updateData(appData);
        }
    }

    // Receive notification
    onReceiveNotification(data) {
        this.showNotification(data.notification);
    }

    // Update app data
    onUpdateAppData(data) {
        const { app, data: appData } = data;
        
        if (window.PhoneApps && window.PhoneApps[app]) {
            window.PhoneApps[app].updateData(appData);
        }
    }

    // Receive call
    onReceiveCall(data) {
        this.showIncomingCall(data.callData);
    }

    // Call ended
    onCallEnded() {
        this.hideIncomingCall();
    }

    // Update player info in UI
    updatePlayerInfo() {
        // Update status bar with player info
        if (this.playerData) {
            // Update carrier name, signal strength, etc.
            const carrier = document.querySelector('.carrier');
            if (carrier) {
                carrier.textContent = this.framework || 'M4SON1';
            }
        }
    }

    // Show notification
    showNotification(notification) {
        const container = document.getElementById('notification-container');
        const notificationEl = document.createElement('div');
        notificationEl.className = `notification ${notification.type || 'info'}`;
        
        notificationEl.innerHTML = `
            <div class="notification-icon">
                <i class="fas fa-${notification.icon || 'bell'}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-title">${notification.title}</div>
                <div class="notification-message">${notification.message}</div>
            </div>
        `;
        
        container.appendChild(notificationEl);
        
        // Play notification sound
        this.playNotificationSound();
        
        // Auto-remove after duration
        setTimeout(() => {
            if (notificationEl.parentNode) {
                notificationEl.style.animation = 'slideOut 0.3s ease-out forwards';
                setTimeout(() => {
                    if (notificationEl.parentNode) {
                        container.removeChild(notificationEl);
                    }
                }, 300);
            }
        }, notification.duration || 5000);
    }

    // Show incoming call
    showIncomingCall(callData) {
        // Implementation for incoming call UI
        console.log('Incoming call:', callData);
    }

    // Hide incoming call
    hideIncomingCall() {
        // Implementation for hiding call UI
        console.log('Call ended');
    }
    
    // Update phone colors
    onUpdatePhoneColors(data) {
        if (window.phoneInterface) {
            window.phoneInterface.updatePhoneColors(data.frameColor, data.buttonColor);
        }
    }

    // Play notification sound
    playNotificationSound() {
        const audio = document.getElementById('notification-sound');
        if (audio) {
            audio.currentTime = 0;
            audio.play().catch(e => console.log('Could not play notification sound'));
        }
    }

    // Send message to client
    sendMessage(action, data = {}) {
        if (!this.initialized) {
            console.warn('Framework not initialized');
            return;
        }

        fetch(`https://${GetParentResourceName()}/${action}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        }).catch(err => {
            console.error('Error sending message:', err);
        });
    }

    // Get player data
    getPlayerData() {
        return this.playerData;
    }

    // Get framework
    getFramework() {
        return this.framework;
    }

    // Request app data
    requestAppData(app) {
        this.sendMessage('appAction', {
            app: app,
            action: 'getData'
        });
    }

    // Send app action
    sendAppAction(app, action, data = {}) {
        this.sendMessage('appAction', {
            app: app,
            action: action,
            data: data
        });
    }

    // Close phone
    closePhone() {
        this.sendMessage('closePhone');
    }
}

// Create global framework instance
window.PhoneFramework = new PhoneFramework();

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.PhoneFramework.init();
});

// Helper function to get parent resource name
function GetParentResourceName() {
    return 'm4son1_studio_phone';
}

// CSS for slide out animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
