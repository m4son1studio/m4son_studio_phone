// Phone Apps Manager
class PhoneApps {
    constructor() {
        this.apps = {};
        this.currentAppData = {};
        this.init();
    }

    init() {
        // Initialize all apps
        this.apps = {
            phone: new PhoneApp(),
            messages: new MessagesApp(),
            contacts: new ContactsApp(),
            maps: new MapsApp(),
            camera: new CameraApp(),
            photos: new PhotosApp(),
            music: new MusicApp(),
            weather: new WeatherApp(),
            banking: new BankingApp(),
            email: new EmailApp(),
            calendar: new CalendarApp(),
            notes: new NotesApp(),
            clock: new ClockApp(),
            calculator: new CalculatorApp(),
            settings: new SettingsApp()
        };

        console.log('Phone apps initialized');
    }

    getApp(appName) {
        return this.apps[appName];
    }
}

// Base App Class
class BaseApp {
    constructor(name) {
        this.name = name;
        this.data = null;
        this.isOpen = false;
    }

    open() {
        this.isOpen = true;
        this.render();
    }

    close() {
        this.isOpen = false;
    }

    updateData(data) {
        this.data = data;
        if (this.isOpen) {
            this.render();
        }
    }

    render() {
        // Override in subclasses
    }

    sendAction(action, data = {}) {
        if (window.PhoneFramework) {
            window.PhoneFramework.sendAppAction(this.name, action, data);
        }
    }
}

// Phone App
class PhoneApp extends BaseApp {
    constructor() {
        super('phone');
        this.currentNumber = '';
        this.inCall = false;
        this.callStartTime = null;
    }

    render() {
        const content = document.getElementById('app-content');
        content.innerHTML = `
            <div class="phone-app">
                <div class="phone-display" id="phone-display">
                    ${this.currentNumber || 'Enter number'}
                </div>
                
                <div class="phone-keypad">
                    ${this.renderKeypad()}
                </div>
                
                <div class="call-controls">
                    <button class="call-btn call" onclick="phoneApp.makeCall()">
                        <i class="fas fa-phone"></i>
                    </button>
                    <button class="call-btn end" onclick="phoneApp.endCall()">
                        <i class="fas fa-phone-slash"></i>
                    </button>
                </div>
                
                <div class="recent-calls">
                    <h3>Recent Calls</h3>
                    <div id="recent-calls-list">
                        ${this.renderRecentCalls()}
                    </div>
                </div>
            </div>
        `;

        // Set up global reference
        window.phoneApp = this;
    }

    renderKeypad() {
        const keys = [
            ['1', '2', '3'],
            ['4', '5', '6'],
            ['7', '8', '9'],
            ['*', '0', '#']
        ];

        return keys.map(row => 
            row.map(key => `
                <button class="keypad-btn" onclick="phoneApp.addDigit('${key}')">
                    ${key}
                </button>
            `).join('')
        ).join('');
    }

    renderRecentCalls() {
        if (!this.data || this.data.length === 0) {
            return '<div class="empty-state">No recent calls</div>';
        }

        return this.data.map(call => `
            <div class="app-list-item" onclick="phoneApp.callNumber('${call.caller_number || call.receiver_number}')">
                <div class="list-item-icon ${call.status === 'missed' ? 'red' : 'green'}">
                    <i class="fas fa-phone"></i>
                </div>
                <div class="list-item-content">
                    <div class="list-item-title">${call.caller_number || call.receiver_number}</div>
                    <div class="list-item-subtitle">${call.status} • ${formatTime(call.created_at)}</div>
                </div>
                <div class="list-item-meta">
                    ${call.duration ? `${Math.floor(call.duration / 60)}:${(call.duration % 60).toString().padStart(2, '0')}` : ''}
                </div>
            </div>
        `).join('');
    }

    addDigit(digit) {
        if (this.currentNumber.length < 15) {
            this.currentNumber += digit;
            this.updateDisplay();
        }
    }

    updateDisplay() {
        const display = document.getElementById('phone-display');
        if (display) {
            display.textContent = this.currentNumber || 'Enter number';
        }
    }

    makeCall() {
        if (this.currentNumber.length > 0) {
            this.sendAction('call', { number: this.currentNumber });
            this.inCall = true;
            this.callStartTime = Date.now();
        }
    }

    endCall() {
        if (this.inCall) {
            const duration = Math.floor((Date.now() - this.callStartTime) / 1000);
            this.sendAction('endCall', { duration: duration });
            this.inCall = false;
            this.callStartTime = null;
        }
        this.currentNumber = '';
        this.updateDisplay();
    }

    callNumber(number) {
        this.currentNumber = number;
        this.updateDisplay();
        this.makeCall();
    }
}

// Messages App
class MessagesApp extends BaseApp {
    constructor() {
        super('messages');
        this.currentThread = null;
        this.threads = {};
    }

    render() {
        const content = document.getElementById('app-content');
        
        if (this.currentThread) {
            content.innerHTML = this.renderThread();
        } else {
            content.innerHTML = this.renderThreadList();
        }
    }

    renderThreadList() {
        const threads = this.groupMessagesByThread();
        
        if (Object.keys(threads).length === 0) {
            return '<div class="empty-state">No messages</div>';
        }

        return `
            <div class="messages-list">
                ${Object.entries(threads).map(([number, messages]) => {
                    const lastMessage = messages[messages.length - 1];
                    return `
                        <div class="message-thread" onclick="messagesApp.openThread('${number}')">
                            <div class="list-item-icon blue">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="list-item-content">
                                <div class="list-item-title">${number}</div>
                                <div class="list-item-subtitle">${lastMessage.message}</div>
                            </div>
                            <div class="list-item-meta">
                                ${formatTime(lastMessage.created_at)}
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    }

    renderThread() {
        const messages = this.threads[this.currentThread] || [];
        
        return `
            <div class="message-thread-view">
                <div class="thread-header">
                    <button class="back-btn" onclick="messagesApp.closeThread()">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    <h3>${this.currentThread}</h3>
                </div>
                
                <div class="messages-container">
                    ${messages.map(msg => `
                        <div class="message-bubble ${msg.sender_identifier === 'me' ? 'sent' : 'received'}">
                            ${msg.message}
                        </div>
                        <div class="message-time">
                            ${formatTime(msg.created_at)}
                        </div>
                    `).join('')}
                </div>
                
                <div class="message-input-container">
                    <input type="text" class="message-input" placeholder="Type a message..." id="message-input">
                    <button class="send-btn" onclick="messagesApp.sendMessage()">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        `;
    }

    groupMessagesByThread() {
        if (!this.data) return {};
        
        const threads = {};
        this.data.forEach(msg => {
            const otherNumber = msg.sender_number === 'me' ? msg.receiver_number : msg.sender_number;
            if (!threads[otherNumber]) {
                threads[otherNumber] = [];
            }
            threads[otherNumber].push(msg);
        });
        
        this.threads = threads;
        return threads;
    }

    openThread(number) {
        this.currentThread = number;
        this.render();
        
        // Set up global reference
        window.messagesApp = this;
    }

    closeThread() {
        this.currentThread = null;
        this.render();
    }

    sendMessage() {
        const input = document.getElementById('message-input');
        const message = input.value.trim();
        
        if (message && this.currentThread) {
            this.sendAction('send', {
                number: this.currentThread,
                message: message
            });
            input.value = '';
        }
    }
}

// Contacts App
class ContactsApp extends BaseApp {
    constructor() {
        super('contacts');
        this.editingContact = null;
    }

    render() {
        const content = document.getElementById('app-content');
        
        if (this.editingContact) {
            content.innerHTML = this.renderEditForm();
        } else {
            content.innerHTML = this.renderContactsList();
        }
    }

    renderContactsList() {
        const hasContacts = this.data && this.data.length > 0;
        
        return `
            <div class="contacts-app">
                <button class="app-button" onclick="contactsApp.addContact()">
                    <i class="fas fa-plus"></i> Add Contact
                </button>
                
                <div class="contacts-list">
                    ${hasContacts ? this.data.map(contact => `
                        <div class="app-list-item" onclick="contactsApp.editContact(${contact.id})">
                            <div class="list-item-icon gray">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="list-item-content">
                                <div class="list-item-title">${contact.name}</div>
                                <div class="list-item-subtitle">${contact.number}</div>
                            </div>
                            <div class="list-item-meta">
                                <i class="fas fa-chevron-right"></i>
                            </div>
                        </div>
                    `).join('') : '<div class="empty-state">No contacts</div>'}
                </div>
            </div>
        `;
    }

    renderEditForm() {
        const isNew = this.editingContact === 'new';
        const contact = isNew ? { name: '', number: '', avatar: '' } : 
                      this.data.find(c => c.id === this.editingContact);

        return `
            <div class="contact-edit-form">
                <div class="form-header">
                    <button class="back-btn" onclick="contactsApp.cancelEdit()">
                        <i class="fas fa-times"></i>
                    </button>
                    <h3>${isNew ? 'Add' : 'Edit'} Contact</h3>
                </div>
                
                <div class="form-content">
                    <input type="text" class="app-input" placeholder="Name" 
                           value="${contact.name}" id="contact-name">
                    <input type="text" class="app-input" placeholder="Phone Number" 
                           value="${contact.number}" id="contact-number">
                    <input type="text" class="app-input" placeholder="Avatar URL (optional)" 
                           value="${contact.avatar || ''}" id="contact-avatar">
                    
                    <div class="form-actions">
                        <button class="app-button" onclick="contactsApp.saveContact()">
                            ${isNew ? 'Add' : 'Update'} Contact
                        </button>
                        ${!isNew ? `
                            <button class="app-button danger" onclick="contactsApp.deleteContact()">
                                Delete Contact
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }

    addContact() {
        this.editingContact = 'new';
        this.render();
        window.contactsApp = this;
    }

    editContact(id) {
        this.editingContact = id;
        this.render();
        window.contactsApp = this;
    }

    saveContact() {
        const name = document.getElementById('contact-name').value.trim();
        const number = document.getElementById('contact-number').value.trim();
        const avatar = document.getElementById('contact-avatar').value.trim();

        if (!name || !number) {
            alert('Name and number are required');
            return;
        }

        const action = this.editingContact === 'new' ? 'add' : 'update';
        const data = { name, number, avatar };
        
        if (action === 'update') {
            data.id = this.editingContact;
        }

        this.sendAction(action, data);
        this.cancelEdit();
    }

    deleteContact() {
        if (confirm('Are you sure you want to delete this contact?')) {
            this.sendAction('delete', { id: this.editingContact });
            this.cancelEdit();
        }
    }

    cancelEdit() {
        this.editingContact = null;
        this.render();
    }
}

// Maps App
class MapsApp extends BaseApp {
    constructor() {
        super('maps');
        this.currentLocation = null;
    }

    render() {
        const content = document.getElementById('app-content');
        content.innerHTML = `
            <div class="maps-app">
                <div class="map-container">
                    <div class="map-placeholder">
                        <i class="fas fa-map-marker-alt"></i>
                        <p>GPS Location</p>
                        ${this.data ? `
                            <div class="coordinates">
                                <p>X: ${this.data.x.toFixed(2)}</p>
                                <p>Y: ${this.data.y.toFixed(2)}</p>
                                <p>Z: ${this.data.z.toFixed(2)}</p>
                            </div>
                        ` : ''}
                    </div>
                </div>
                
                <div class="map-controls">
                    <button class="app-button" onclick="mapsApp.refreshLocation()">
                        <i class="fas fa-sync"></i> Refresh Location
                    </button>
                    <button class="app-button secondary" onclick="mapsApp.shareLocation()">
                        <i class="fas fa-share"></i> Share Location
                    </button>
                </div>
            </div>
        `;
        
        window.mapsApp = this;
    }

    refreshLocation() {
        this.sendAction('getLocation');
    }

    shareLocation() {
        if (this.data) {
            // Copy coordinates to clipboard or share
            const coords = `${this.data.x.toFixed(2)}, ${this.data.y.toFixed(2)}`;
            navigator.clipboard.writeText(coords).then(() => {
                alert('Location copied to clipboard');
            });
        }
    }
}

// Camera App
class CameraApp extends BaseApp {
    constructor() {
        super('camera');
    }

    render() {
        const content = document.getElementById('app-content');
        content.innerHTML = `
            <div class="camera-app">
                <div class="camera-viewfinder">
                    <div class="camera-placeholder">
                        <i class="fas fa-camera"></i>
                        <p>Camera View</p>
                    </div>
                </div>
                
                <div class="camera-controls">
                    <button class="camera-btn" onclick="cameraApp.switchCamera()">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                    <button class="camera-btn capture" onclick="cameraApp.takePhoto()">
                        <i class="fas fa-camera"></i>
                    </button>
                    <button class="camera-btn" onclick="cameraApp.openGallery()">
                        <i class="fas fa-images"></i>
                    </button>
                </div>
            </div>
        `;
        
        window.cameraApp = this;
    }

    takePhoto() {
        this.sendAction('takePhoto');
    }

    switchCamera() {
        // Switch between front and back camera
        console.log('Switching camera');
    }

    openGallery() {
        // Open photos app
        window.PhoneInterface.openApp('photos');
    }
}

// Photos App
class PhotosApp extends BaseApp {
    constructor() {
        super('photos');
        this.selectedPhoto = null;
    }

    render() {
        const content = document.getElementById('app-content');
        content.innerHTML = `
            <div class="photos-app">
                <div class="photos-grid">
                    ${this.renderPhotos()}
                </div>
            </div>
        `;
        
        window.photosApp = this;
    }

    renderPhotos() {
        if (!this.data || this.data.length === 0) {
            return '<div class="empty-state">No photos</div>';
        }

        return this.data.map(photo => `
            <div class="photo-item" onclick="photosApp.viewPhoto(${photo.id})">
                <i class="fas fa-image"></i>
            </div>
        `).join('');
    }

    viewPhoto(id) {
        this.selectedPhoto = id;
        // Show photo viewer
        console.log('Viewing photo:', id);
    }
}

// Music App
class MusicApp extends BaseApp {
    constructor() {
        super('music');
        this.isPlaying = false;
        this.currentTrack = null;
    }

    render() {
        const content = document.getElementById('app-content');
        content.innerHTML = `
            <div class="music-app">
                <div class="music-player">
                    <div class="album-art">
                        <i class="fas fa-music"></i>
                    </div>
                    
                    <div class="track-info">
                        <h3>${this.currentTrack || 'No track selected'}</h3>
                        <p>Unknown Artist</p>
                    </div>
                    
                    <div class="player-controls">
                        <button class="player-btn" onclick="musicApp.previousTrack()">
                            <i class="fas fa-step-backward"></i>
                        </button>
                        <button class="player-btn play" onclick="musicApp.togglePlay()">
                            <i class="fas fa-${this.isPlaying ? 'pause' : 'play'}"></i>
                        </button>
                        <button class="player-btn" onclick="musicApp.nextTrack()">
                            <i class="fas fa-step-forward"></i>
                        </button>
                    </div>
                </div>
                
                <div class="playlist">
                    <h3>Recently Played</h3>
                    <div class="empty-state">No music available</div>
                </div>
            </div>
        `;
        
        window.musicApp = this;
    }

    togglePlay() {
        this.isPlaying = !this.isPlaying;
        this.render();
    }

    previousTrack() {
        console.log('Previous track');
    }

    nextTrack() {
        console.log('Next track');
    }
}

// Weather App
class WeatherApp extends BaseApp {
    constructor() {
        super('weather');
    }

    render() {
        const content = document.getElementById('app-content');
        
        if (!this.data) {
            content.innerHTML = '<div class="app-loading"><div class="loading-spinner"></div></div>';
            return;
        }

        content.innerHTML = `
            <div class="weather-app">
                <div class="weather-card">
                    <div class="weather-location">${this.data.location}</div>
                    <div class="weather-temp">${this.data.temperature}°</div>
                    <div class="weather-condition">${this.data.condition}</div>
                    
                    <div class="weather-details">
                        <div class="weather-detail">
                            <div class="weather-detail-label">Humidity</div>
                            <div class="weather-detail-value">${this.data.humidity}%</div>
                        </div>
                        <div class="weather-detail">
                            <div class="weather-detail-label">Wind</div>
                            <div class="weather-detail-value">${this.data.windSpeed} mph</div>
                        </div>
                    </div>
                </div>
                
                <div class="weather-forecast">
                    <h3>5-Day Forecast</h3>
                    ${this.data.forecast.map(day => `
                        <div class="forecast-item">
                            <div class="forecast-day">${day.day}</div>
                            <div class="forecast-condition">${day.condition}</div>
                            <div class="forecast-temp">${day.high}°/${day.low}°</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
}

// Banking App
class BankingApp extends BaseApp {
    constructor() {
        super('banking');
        this.showTransfer = false;
    }

    render() {
        const content = document.getElementById('app-content');
        
        if (this.showTransfer) {
            content.innerHTML = this.renderTransferForm();
        } else {
            content.innerHTML = this.renderAccounts();
        }
    }

    renderAccounts() {
        if (!this.data || this.data.length === 0) {
            return '<div class="empty-state">No bank accounts</div>';
        }

        return `
            <div class="banking-app">
                ${this.data.map(account => `
                    <div class="account-card">
                        <div class="account-balance">$${account.balance.toFixed(2)}</div>
                        <div class="account-number">****${account.account_number.slice(-4)}</div>
                        <div class="account-type">${account.account_type}</div>
                    </div>
                    
                    <div class="account-actions">
                        <button class="app-button" onclick="bankingApp.showTransfer()">
                            Transfer Money
                        </button>
                        <button class="app-button secondary" onclick="bankingApp.viewTransactions(${account.id})">
                            View Transactions
                        </button>
                    </div>
                    
                    <div class="recent-transactions">
                        <h3>Recent Transactions</h3>
                        ${account.transactions ? account.transactions.map(tx => `
                            <div class="transaction-item">
                                <div class="transaction-info">
                                    <div class="transaction-description">${tx.description}</div>
                                    <div class="transaction-date">${formatDate(tx.created_at)}</div>
                                </div>
                                <div class="transaction-amount ${tx.amount > 0 ? 'positive' : 'negative'}">
                                    ${tx.amount > 0 ? '+' : ''}$${Math.abs(tx.amount).toFixed(2)}
                                </div>
                            </div>
                        `).join('') : '<div class="empty-state">No transactions</div>'}
                    </div>
                `).join('')}
            </div>
        `;
    }

    renderTransferForm() {
        return `
            <div class="transfer-form">
                <div class="form-header">
                    <button class="back-btn" onclick="bankingApp.hideTransfer()">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    <h3>Transfer Money</h3>
                </div>
                
                <div class="form-content">
                    <input type="text" class="app-input" placeholder="Recipient Phone Number" id="transfer-to">
                    <input type="number" class="app-input" placeholder="Amount" id="transfer-amount">
                    <input type="text" class="app-input" placeholder="Description" id="transfer-description">
                    
                    <button class="app-button" onclick="bankingApp.sendTransfer()">
                        Send Transfer
                    </button>
                </div>
            </div>
        `;
    }

    showTransfer() {
        this.showTransfer = true;
        this.render();
        window.bankingApp = this;
    }

    hideTransfer() {
        this.showTransfer = false;
        this.render();
    }

    sendTransfer() {
        const to = document.getElementById('transfer-to').value.trim();
        const amount = parseFloat(document.getElementById('transfer-amount').value);
        const description = document.getElementById('transfer-description').value.trim();

        if (!to || !amount || amount <= 0) {
            alert('Please fill in all fields correctly');
            return;
        }

        this.sendAction('transfer', {
            receiverNumber: to,
            amount: amount,
            description: description
        });

        this.hideTransfer();
    }

    viewTransactions(accountId) {
        console.log('Viewing transactions for account:', accountId);
    }
}

// Email App
class EmailApp extends BaseApp {
    constructor() {
        super('email');
        this.composing = false;
    }

    render() {
        const content = document.getElementById('app-content');
        
        if (this.composing) {
            content.innerHTML = this.renderCompose();
        } else {
            content.innerHTML = this.renderInbox();
        }
    }

    renderInbox() {
        const hasEmails = this.data && this.data.length > 0;
        
        return `
            <div class="email-app">
                <button class="app-button" onclick="emailApp.compose()">
                    <i class="fas fa-edit"></i> Compose
                </button>
                
                <div class="email-list">
                    ${hasEmails ? this.data.map(email => `
                        <div class="app-list-item ${email.read_status ? '' : 'unread'}">
                            <div class="list-item-icon blue">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="list-item-content">
                                <div class="list-item-title">${email.subject}</div>
                                <div class="list-item-subtitle">${email.sender}</div>
                            </div>
                            <div class="list-item-meta">
                                ${formatTime(email.created_at)}
                            </div>
                        </div>
                    `).join('') : '<div class="empty-state">No emails</div>'}
                </div>
            </div>
        `;
    }

    renderCompose() {
        return `
            <div class="email-compose">
                <div class="form-header">
                    <button class="back-btn" onclick="emailApp.cancelCompose()">
                        <i class="fas fa-times"></i>
                    </button>
                    <h3>New Email</h3>
                </div>
                
                <div class="form-content">
                    <input type="text" class="app-input" placeholder="To" id="email-to">
                    <input type="text" class="app-input" placeholder="Subject" id="email-subject">
                    <textarea class="app-textarea" placeholder="Message" id="email-body"></textarea>
                    
                    <button class="app-button" onclick="emailApp.sendEmail()">
                        Send Email
                    </button>
                </div>
            </div>
        `;
    }

    compose() {
        this.composing = true;
        this.render();
        window.emailApp = this;
    }

    cancelCompose() {
        this.composing = false;
        this.render();
    }

    sendEmail() {
        const to = document.getElementById('email-to').value.trim();
        const subject = document.getElementById('email-subject').value.trim();
        const body = document.getElementById('email-body').value.trim();

        if (!to || !subject || !body) {
            alert('Please fill in all fields');
            return;
        }

        this.sendAction('send', {
            to: to,
            subject: subject,
            body: body,
            from: 'you@phone.com'
        });

        this.cancelCompose();
    }
}

// Calendar App
class CalendarApp extends BaseApp {
    constructor() {
        super('calendar');
        this.currentDate = new Date();
        this.addingEvent = false;
    }

    render() {
        const content = document.getElementById('app-content');
        
        if (this.addingEvent) {
            content.innerHTML = this.renderAddEvent();
        } else {
            content.innerHTML = this.renderCalendar();
        }
    }

    renderCalendar() {
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December'];
        
        return `
            <div class="calendar-app">
                <div class="calendar-header">
                    <button class="calendar-nav" onclick="calendarApp.previousMonth()">
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    <div class="calendar-month">
                        ${monthNames[this.currentDate.getMonth()]} ${this.currentDate.getFullYear()}
                    </div>
                    <button class="calendar-nav" onclick="calendarApp.nextMonth()">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
                
                <div class="calendar-grid">
                    ${this.renderCalendarGrid()}
                </div>
                
                <button class="app-button" onclick="calendarApp.addEvent()">
                    <i class="fas fa-plus"></i> Add Event
                </button>
                
                <div class="events-list">
                    <h3>Upcoming Events</h3>
                    ${this.renderEvents()}
                </div>
            </div>
        `;
    }

    renderCalendarGrid() {
        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const startDate = new Date(firstDay);
        startDate.setDate(startDate.getDate() - firstDay.getDay());
        
        const days = [];
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        
        // Add day headers
        dayNames.forEach(day => {
            days.push(`<div class="calendar-day-header">${day}</div>`);
        });
        
        // Add calendar days
        for (let i = 0; i < 42; i++) {
            const date = new Date(startDate);
            date.setDate(startDate.getDate() + i);
            
            const isToday = date.toDateString() === new Date().toDateString();
            const isCurrentMonth = date.getMonth() === month;
            
            days.push(`
                <div class="calendar-day ${isToday ? 'today' : ''} ${isCurrentMonth ? '' : 'other-month'}">
                    ${date.getDate()}
                </div>
            `);
        }
        
        return days.join('');
    }

    renderEvents() {
        if (!this.data || this.data.length === 0) {
            return '<div class="empty-state">No events</div>';
        }

        return this.data.map(event => `
            <div class="event-item">
                <div class="event-title">${event.title}</div>
                <div class="event-time">${formatDateTime(event.start_date)}</div>
            </div>
        `).join('');
    }

    renderAddEvent() {
        return `
            <div class="add-event-form">
                <div class="form-header">
                    <button class="back-btn" onclick="calendarApp.cancelAddEvent()">
                        <i class="fas fa-times"></i>
                    </button>
                    <h3>Add Event</h3>
                </div>
                
                <div class="form-content">
                    <input type="text" class="app-input" placeholder="Event Title" id="event-title">
                    <textarea class="app-textarea" placeholder="Description" id="event-description"></textarea>
                    <input type="datetime-local" class="app-input" id="event-start">
                    <input type="datetime-local" class="app-input" id="event-end">
                    
                    <button class="app-button" onclick="calendarApp.saveEvent()">
                        Add Event
                    </button>
                </div>
            </div>
        `;
    }

    previousMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() - 1);
        this.render();
    }

    nextMonth() {
        this.currentDate.setMonth(this.currentDate.getMonth() + 1);
        this.render();
    }

    addEvent() {
        this.addingEvent = true;
        this.render();
        window.calendarApp = this;
    }

    cancelAddEvent() {
        this.addingEvent = false;
        this.render();
    }

    saveEvent() {
        const title = document.getElementById('event-title').value.trim();
        const description = document.getElementById('event-description').value.trim();
        const startDate = document.getElementById('event-start').value;
        const endDate = document.getElementById('event-end').value;

        if (!title || !startDate || !endDate) {
            alert('Please fill in all required fields');
            return;
        }

        this.sendAction('add', {
            title: title,
            description: description,
            startDate: startDate,
            endDate: endDate,
            allDay: false
        });

        this.cancelAddEvent();
    }
}

// Notes App
class NotesApp extends BaseApp {
    constructor() {
        super('notes');
        this.editingNote = null;
    }

    render() {
        const content = document.getElementById('app-content');
        
        if (this.editingNote) {
            content.innerHTML = this.renderEditNote();
        } else {
            content.innerHTML = this.renderNotesList();
        }
    }

    renderNotesList() {
        const hasNotes = this.data && this.data.length > 0;
        
        return `
            <div class="notes-app">
                <button class="app-button" onclick="notesApp.addNote()">
                    <i class="fas fa-plus"></i> New Note
                </button>
                
                <div class="notes-list">
                    ${hasNotes ? this.data.map(note => `
                        <div class="note-item" onclick="notesApp.editNote(${note.id})">
                            <div class="note-title">${note.title}</div>
                            <div class="note-preview">${note.content.substring(0, 100)}...</div>
                            <div class="note-date">${formatDate(note.updated_at)}</div>
                        </div>
                    `).join('') : '<div class="empty-state">No notes</div>'}
                </div>
            </div>
        `;
    }

    renderEditNote() {
        const isNew = this.editingNote === 'new';
        const note = isNew ? { title: '', content: '' } : 
                    this.data.find(n => n.id === this.editingNote);

        return `
            <div class="note-edit-form">
                <div class="form-header">
                    <button class="back-btn" onclick="notesApp.cancelEdit()">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    <button class="save-btn" onclick="notesApp.saveNote()">
                        Save
                    </button>
                </div>
                
                <div class="form-content">
                    <input type="text" class="app-input" placeholder="Title" 
                           value="${note.title}" id="note-title">
                    <textarea class="app-textarea" placeholder="Start writing..." 
                              id="note-content" style="height: 300px;">${note.content}</textarea>
                    
                    ${!isNew ? `
                        <button class="app-button danger" onclick="notesApp.deleteNote()">
                            Delete Note
                        </button>
                    ` : ''}
                </div>
            </div>
        `;
    }

    addNote() {
        this.editingNote = 'new';
        this.render();
        window.notesApp = this;
    }

    editNote(id) {
        this.editingNote = id;
        this.render();
        window.notesApp = this;
    }

    saveNote() {
        const title = document.getElementById('note-title').value.trim();
        const content = document.getElementById('note-content').value.trim();

        if (!title || !content) {
            alert('Please fill in both title and content');
            return;
        }

        const action = this.editingNote === 'new' ? 'add' : 'update';
        const data = { title, content };
        
        if (action === 'update') {
            data.id = this.editingNote;
        }

        this.sendAction(action, data);
        this.cancelEdit();
    }

    deleteNote() {
        if (confirm('Are you sure you want to delete this note?')) {
            this.sendAction('delete', { id: this.editingNote });
            this.cancelEdit();
        }
    }

    cancelEdit() {
        this.editingNote = null;
        this.render();
    }
}

// Clock App
class ClockApp extends BaseApp {
    constructor() {
        super('clock');
        this.mode = 'clock'; // clock, timer, stopwatch, alarm
        this.timerInterval = null;
        this.timerTime = 0;
    }

    render() {
        const content = document.getElementById('app-content');
        content.innerHTML = `
            <div class="clock-app">
                <div class="clock-tabs">
                    <button class="clock-tab ${this.mode === 'clock' ? 'active' : ''}" 
                            onclick="clockApp.setMode('clock')">Clock</button>
                    <button class="clock-tab ${this.mode === 'timer' ? 'active' : ''}" 
                            onclick="clockApp.setMode('timer')">Timer</button>
                    <button class="clock-tab ${this.mode === 'stopwatch' ? 'active' : ''}" 
                            onclick="clockApp.setMode('stopwatch')">Stopwatch</button>
                    <button class="clock-tab ${this.mode === 'alarm' ? 'active' : ''}" 
                            onclick="clockApp.setMode('alarm')">Alarm</button>
                </div>
                
                <div class="clock-content">
                    ${this.renderClockMode()}
                </div>
            </div>
        `;
        
        window.clockApp = this;
    }

    renderClockMode() {
        const now = new Date();
        
        switch (this.mode) {
            case 'clock':
                return `
                    <div class="digital-clock">
                        <div class="time-display">${now.toLocaleTimeString()}</div>
                        <div class="date-display">${now.toLocaleDateString()}</div>
                    </div>
                `;
            
            case 'timer':
                return `
                    <div class="timer-display">
                        <div class="timer-time">${this.formatTime(this.timerTime)}</div>
                        <div class="timer-controls">
                            <button class="app-button" onclick="clockApp.startTimer()">Start</button>
                            <button class="app-button secondary" onclick="clockApp.pauseTimer()">Pause</button>
                            <button class="app-button secondary" onclick="clockApp.resetTimer()">Reset</button>
                        </div>
                    </div>
                `;
            
            case 'stopwatch':
                return `
                    <div class="stopwatch-display">
                        <div class="stopwatch-time">${this.formatTime(this.timerTime)}</div>
                        <div class="stopwatch-controls">
                            <button class="app-button" onclick="clockApp.startStopwatch()">Start</button>
                            <button class="app-button secondary" onclick="clockApp.pauseStopwatch()">Pause</button>
                            <button class="app-button secondary" onclick="clockApp.resetStopwatch()">Reset</button>
                        </div>
                    </div>
                `;
            
            case 'alarm':
                return `
                    <div class="alarm-display">
                        <div class="empty-state">
                            <i class="fas fa-bell"></i>
                            <p>No alarms set</p>
                        </div>
                    </div>
                `;
        }
    }

    setMode(mode) {
        this.mode = mode;
        this.render();
    }

    formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    startTimer() {
        if (!this.timerInterval) {
            this.timerInterval = setInterval(() => {
                this.timerTime--;
                if (this.timerTime <= 0) {
                    this.pauseTimer();
                    alert('Timer finished!');
                }
                this.render();
            }, 1000);
        }
    }

    pauseTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
    }

    resetTimer() {
        this.pauseTimer();
        this.timerTime = 0;
        this.render();
    }

    startStopwatch() {
        if (!this.timerInterval) {
            this.timerInterval = setInterval(() => {
                this.timerTime++;
                this.render();
            }, 1000);
        }
    }

    pauseStopwatch() {
        this.pauseTimer();
    }

    resetStopwatch() {
        this.resetTimer();
    }
}

// Calculator App
class CalculatorApp extends BaseApp {
    constructor() {
        super('calculator');
        this.display = '0';
        this.previousValue = null;
        this.operation = null;
        this.waitingForNewValue = false;
    }

    render() {
        const content = document.getElementById('app-content');
        content.innerHTML = `
            <div class="calculator-app">
                <div class="calculator-display">${this.display}</div>
                
                <div class="calculator-buttons">
                    <button class="calc-btn function" onclick="calculatorApp.clear()">C</button>
                    <button class="calc-btn function" onclick="calculatorApp.toggleSign()">±</button>
                    <button class="calc-btn function" onclick="calculatorApp.percentage()">%</button>
                    <button class="calc-btn operator" onclick="calculatorApp.setOperation('÷')">÷</button>
                    
                    <button class="calc-btn number" onclick="calculatorApp.inputNumber('7')">7</button>
                    <button class="calc-btn number" onclick="calculatorApp.inputNumber('8')">8</button>
                    <button class="calc-btn number" onclick="calculatorApp.inputNumber('9')">9</button>
                    <button class="calc-btn operator" onclick="calculatorApp.setOperation('×')">×</button>
                    
                    <button class="calc-btn number" onclick="calculatorApp.inputNumber('4')">4</button>
                    <button class="calc-btn number" onclick="calculatorApp.inputNumber('5')">5</button>
                    <button class="calc-btn number" onclick="calculatorApp.inputNumber('6')">6</button>
                    <button class="calc-btn operator" onclick="calculatorApp.setOperation('-')">-</button>
                    
                    <button class="calc-btn number" onclick="calculatorApp.inputNumber('1')">1</button>
                    <button class="calc-btn number" onclick="calculatorApp.inputNumber('2')">2</button>
                    <button class="calc-btn number" onclick="calculatorApp.inputNumber('3')">3</button>
                    <button class="calc-btn operator" onclick="calculatorApp.setOperation('+')">+</button>
                    
                    <button class="calc-btn number zero" onclick="calculatorApp.inputNumber('0')">0</button>
                    <button class="calc-btn number" onclick="calculatorApp.inputDecimal()">.</button>
                    <button class="calc-btn operator" onclick="calculatorApp.calculate()">=</button>
                </div>
            </div>
        `;
        
        window.calculatorApp = this;
    }

    inputNumber(num) {
        if (this.waitingForNewValue) {
            this.display = num;
            this.waitingForNewValue = false;
        } else {
            this.display = this.display === '0' ? num : this.display + num;
        }
        this.render();
    }

    inputDecimal() {
        if (this.waitingForNewValue) {
            this.display = '0.';
            this.waitingForNewValue = false;
        } else if (this.display.indexOf('.') === -1) {
            this.display += '.';
        }
        this.render();
    }

    setOperation(op) {
        if (this.previousValue !== null && !this.waitingForNewValue) {
            this.calculate();
        }
        
        this.previousValue = parseFloat(this.display);
        this.operation = op;
        this.waitingForNewValue = true;
    }

    calculate() {
        if (this.previousValue === null || this.operation === null) return;
        
        const current = parseFloat(this.display);
        let result;
        
        switch (this.operation) {
            case '+':
                result = this.previousValue + current;
                break;
            case '-':
                result = this.previousValue - current;
                break;
            case '×':
                result = this.previousValue * current;
                break;
            case '÷':
                result = this.previousValue / current;
                break;
            default:
                return;
        }
        
        this.display = result.toString();
        this.previousValue = null;
        this.operation = null;
        this.waitingForNewValue = true;
        this.render();
    }

    clear() {
        this.display = '0';
        this.previousValue = null;
        this.operation = null;
        this.waitingForNewValue = false;
        this.render();
    }

    toggleSign() {
        this.display = (parseFloat(this.display) * -1).toString();
        this.render();
    }

    percentage() {
        this.display = (parseFloat(this.display) / 100).toString();
        this.render();
    }
}

// Settings App
class SettingsApp extends BaseApp {
    constructor() {
        super('settings');
        this.settings = {
            notifications: true,
            sounds: true,
            vibration: true,
            darkMode: true,
            autoLock: true
        };
    }

    render() {
        const content = document.getElementById('app-content');
        content.innerHTML = `
            <div class="settings-app">
                <div class="settings-section">
                    <div class="settings-section-title">General</div>
                    
                    <div class="settings-item">
                        <div class="settings-label">Notifications</div>
                        <div class="settings-toggle ${this.settings.notifications ? 'active' : ''}" 
                             onclick="settingsApp.toggleSetting('notifications')">
                        </div>
                    </div>
                    
                    <div class="settings-item">
                        <div class="settings-label">Sounds</div>
                        <div class="settings-toggle ${this.settings.sounds ? 'active' : ''}" 
                             onclick="settingsApp.toggleSetting('sounds')">
                        </div>
                    </div>
                    
                    <div class="settings-item">
                        <div class="settings-label">Vibration</div>
                        <div class="settings-toggle ${this.settings.vibration ? 'active' : ''}" 
                             onclick="settingsApp.toggleSetting('vibration')">
                        </div>
                    </div>
                </div>
                
                <div class="settings-section">
                    <div class="settings-section-title">Display</div>
                    
                    <div class="settings-item">
                        <div class="settings-label">Dark Mode</div>
                        <div class="settings-toggle ${this.settings.darkMode ? 'active' : ''}" 
                             onclick="settingsApp.toggleSetting('darkMode')">
                        </div>
                    </div>
                    
                    <div class="settings-item">
                        <div class="settings-label">Auto Lock</div>
                        <div class="settings-toggle ${this.settings.autoLock ? 'active' : ''}" 
                             onclick="settingsApp.toggleSetting('autoLock')">
                        </div>
                    </div>
                </div>
                
                <div class="settings-section">
                    <div class="settings-section-title">About</div>
                    
                    <div class="settings-item">
                        <div class="settings-label">Version</div>
                        <div class="settings-value">1.0.0</div>
                    </div>
                    
                    <div class="settings-item">
                        <div class="settings-label">Developer</div>
                        <div class="settings-value">M4SON1 Studio</div>
                    </div>
                </div>
            </div>
        `;
        
        window.settingsApp = this;
    }

    toggleSetting(setting) {
        this.settings[setting] = !this.settings[setting];
        this.render();
        
        // Save settings
        this.sendAction('updateSettings', this.settings);
    }
}

// Initialize apps manager
window.PhoneApps = new PhoneApps();
