// Main Phone Interface
class PhoneInterface {
    constructor() {
        this.currentApp = 'home';
        this.previousApp = null;
        this.isAnimating = false;
        this.timeInterval = null;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.updateTime();
        this.startTimeUpdates();
        
        console.log('Phone interface initialized');
    }

    setupEventListeners() {
        // App icon clicks
        document.addEventListener('click', (event) => {
            const appIcon = event.target.closest('.app-icon, .dock-icon');
            if (appIcon) {
                const app = appIcon.dataset.app;
                if (app) {
                    this.openApp(app);
                }
            }
        });

        // Back button
        document.addEventListener('click', (event) => {
            if (event.target.closest('.back-btn')) {
                this.goHome();
            }
        });

        // Home indicator click
        document.addEventListener('click', (event) => {
            if (event.target.closest('.home-indicator')) {
                this.goHome();
            }
        });

        // Prevent context menu
        document.addEventListener('contextmenu', (event) => {
            event.preventDefault();
        });

        // Handle escape key
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                if (this.currentApp !== 'home') {
                    this.goHome();
                } else {
                    this.closePhone();
                }
            }
        });
    }

    openApp(appName) {
        if (this.isAnimating || this.currentApp === appName) return;
        
        this.isAnimating = true;
        
        // Handle home screen
        if (appName === 'home') {
            this.goHome();
            return;
        }

        // Set previous app
        this.previousApp = this.currentApp;
        this.currentApp = appName;

        // Update UI
        this.showAppScreen(appName);
        
        // Request app data
        if (window.PhoneFramework) {
            window.PhoneFramework.requestAppData(appName);
        }

        // Load app
        if (window.PhoneApps && window.PhoneApps[appName]) {
            window.PhoneApps[appName].open();
        }

        setTimeout(() => {
            this.isAnimating = false;
        }, 300);
    }

    showAppScreen(appName) {
        const homeScreen = document.getElementById('home-screen');
        const appScreen = document.getElementById('app-screen');
        const appTitle = document.getElementById('app-title');
        const appContent = document.getElementById('app-content');

        // Update app title
        const appConfig = this.getAppConfig(appName);
        appTitle.textContent = appConfig.name || appName;

        // Clear app content
        appContent.innerHTML = '';

        // Show app screen
        homeScreen.classList.remove('active');
        appScreen.classList.add('active');
        
        // Add bounce animation
        appScreen.classList.add('bounce-in');
        setTimeout(() => {
            appScreen.classList.remove('bounce-in');
        }, 300);
    }

    goHome() {
        if (this.isAnimating || this.currentApp === 'home') return;
        
        this.isAnimating = true;
        
        const homeScreen = document.getElementById('home-screen');
        const appScreen = document.getElementById('app-screen');

        // Hide app screen
        appScreen.classList.remove('active');
        homeScreen.classList.add('active');

        // Reset state
        this.previousApp = this.currentApp;
        this.currentApp = 'home';

        setTimeout(() => {
            this.isAnimating = false;
        }, 300);
    }

    closePhone() {
        if (window.PhoneFramework) {
            window.PhoneFramework.closePhone();
        }
    }

    getAppConfig(appName) {
        // Default app configurations
        const configs = {
            phone: { name: 'Phone', icon: 'phone' },
            messages: { name: 'Messages', icon: 'message-circle' },
            contacts: { name: 'Contacts', icon: 'users' },
            maps: { name: 'Maps', icon: 'map' },
            camera: { name: 'Camera', icon: 'camera' },
            photos: { name: 'Photos', icon: 'image' },
            music: { name: 'Music', icon: 'music' },
            weather: { name: 'Weather', icon: 'cloud' },
            banking: { name: 'Banking', icon: 'credit-card' },
            email: { name: 'Mail', icon: 'mail' },
            calendar: { name: 'Calendar', icon: 'calendar' },
            notes: { name: 'Notes', icon: 'edit-3' },
            clock: { name: 'Clock', icon: 'clock' },
            calculator: { name: 'Calculator', icon: 'calculator' },
            settings: { name: 'Settings', icon: 'settings' }
        };

        return configs[appName] || { name: appName, icon: 'smartphone' };
    }

    updateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: false
        });
        
        const timeElement = document.getElementById('current-time');
        if (timeElement) {
            timeElement.textContent = timeString;
        }
    }

    startTimeUpdates() {
        this.timeInterval = setInterval(() => {
            this.updateTime();
        }, 1000);
    }

    stopTimeUpdates() {
        if (this.timeInterval) {
            clearInterval(this.timeInterval);
            this.timeInterval = null;
        }
    }
    
    // Update phone colors based on variant
    updatePhoneColors(frameColor, buttonColor) {
        const phoneElement = document.querySelector('.phone');
        
        if (phoneElement) {
            phoneElement.style.setProperty('--frame-color', frameColor);
            phoneElement.style.setProperty('--button-color', buttonColor);
        }
        
        // Update CSS custom properties
        document.documentElement.style.setProperty('--phone-frame-color', frameColor);
        document.documentElement.style.setProperty('--phone-button-color', buttonColor);
    }

    // Get current app
    getCurrentApp() {
        return this.currentApp;
    }

    // Get previous app
    getPreviousApp() {
        return this.previousApp;
    }

    // Check if animating
    isCurrentlyAnimating() {
        return this.isAnimating;
    }
}

// Utility functions
function formatTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

function formatDate(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleDateString();
}

function formatDateTime(timestamp) {
    const date = new Date(timestamp);
    return date.toLocaleString();
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatPhoneNumber(number) {
    // Format phone number (xxx) xxx-xxxx
    const cleaned = number.replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
        return `(${match[1]}) ${match[2]}-${match[3]}`;
    }
    return number;
}

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

// Create global phone interface
window.PhoneInterface = new PhoneInterface();

// Export global functions
window.goHome = () => window.PhoneInterface.goHome();
window.closePhone = () => window.PhoneInterface.closePhone();

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (window.PhoneInterface) {
        window.PhoneInterface.stopTimeUpdates();
    }
});
