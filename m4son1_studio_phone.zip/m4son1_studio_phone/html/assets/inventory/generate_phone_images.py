#!/usr/bin/env python3
"""
Generate inventory images for all iPhone models
Creates PNG images for each phone variant
"""

import json
import os
from PIL import Image, ImageDraw, ImageFont
import colorsys

# Phone configurations
PHONE_CONFIGS = {
    'iphone_15_pro_max_black': {
        'name': 'iPhone 15 Pro Max',
        'color': 'Black Titanium',
        'frame_color': '#1a1a1a',
        'button_color': '#2a2a2a',
        'rarity': 'legendary'
    },
    'iphone_15_pro_max_white': {
        'name': 'iPhone 15 Pro Max',
        'color': 'White Titanium',
        'frame_color': '#f5f5f5',
        'button_color': '#e0e0e0',
        'rarity': 'legendary'
    },
    'iphone_15_pro_max_blue': {
        'name': 'iPhone 15 Pro Max',
        'color': 'Blue Titanium',
        'frame_color': '#1e3a8a',
        'button_color': '#3b82f6',
        'rarity': 'legendary'
    },
    'iphone_15_pro_max_natural': {
        'name': 'iPhone 15 Pro Max',
        'color': 'Natural Titanium',
        'frame_color': '#8b7355',
        'button_color': '#a0916b',
        'rarity': 'legendary'
    },
    'iphone_15_pro_black': {
        'name': 'iPhone 15 Pro',
        'color': 'Black Titanium',
        'frame_color': '#1a1a1a',
        'button_color': '#2a2a2a',
        'rarity': 'epic'
    },
    'iphone_15_pro_white': {
        'name': 'iPhone 15 Pro',
        'color': 'White Titanium',
        'frame_color': '#f5f5f5',
        'button_color': '#e0e0e0',
        'rarity': 'epic'
    },
    'iphone_15_pro_blue': {
        'name': 'iPhone 15 Pro',
        'color': 'Blue Titanium',
        'frame_color': '#1e3a8a',
        'button_color': '#3b82f6',
        'rarity': 'epic'
    },
    'iphone_15_pro_natural': {
        'name': 'iPhone 15 Pro',
        'color': 'Natural Titanium',
        'frame_color': '#8b7355',
        'button_color': '#a0916b',
        'rarity': 'epic'
    },
    'iphone_15_pink': {
        'name': 'iPhone 15',
        'color': 'Pink',
        'frame_color': '#f8bbd9',
        'button_color': '#ec4899',
        'rarity': 'rare'
    },
    'iphone_15_yellow': {
        'name': 'iPhone 15',
        'color': 'Yellow',
        'frame_color': '#fef08a',
        'button_color': '#eab308',
        'rarity': 'rare'
    },
    'iphone_15_green': {
        'name': 'iPhone 15',
        'color': 'Green',
        'frame_color': '#bbf7d0',
        'button_color': '#22c55e',
        'rarity': 'rare'
    },
    'iphone_15_blue': {
        'name': 'iPhone 15',
        'color': 'Blue',
        'frame_color': '#bfdbfe',
        'button_color': '#3b82f6',
        'rarity': 'rare'
    },
    'iphone_15_black': {
        'name': 'iPhone 15',
        'color': 'Black',
        'frame_color': '#1f2937',
        'button_color': '#374151',
        'rarity': 'rare'
    }
}

def hex_to_rgb(hex_color):
    """Convert hex color to RGB tuple"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def create_phone_image(phone_id, config):
    """Create a phone inventory image"""
    # Image dimensions
    img_size = (512, 512)
    phone_width = 200
    phone_height = 400
    
    # Create image with transparent background
    img = Image.new('RGBA', img_size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Phone position (centered)
    phone_x = (img_size[0] - phone_width) // 2
    phone_y = (img_size[1] - phone_height) // 2 - 20
    
    # Colors
    frame_color = hex_to_rgb(config['frame_color'])
    button_color = hex_to_rgb(config['button_color'])
    screen_color = (0, 0, 0)
    
    # Draw phone frame
    phone_rect = [phone_x, phone_y, phone_x + phone_width, phone_y + phone_height]
    draw.rounded_rectangle(phone_rect, radius=45, fill=frame_color + (255,), outline=button_color + (255,), width=4)
    
    # Draw screen
    screen_margin = 10
    screen_rect = [
        phone_x + screen_margin,
        phone_y + screen_margin,
        phone_x + phone_width - screen_margin,
        phone_y + phone_height - screen_margin
    ]
    draw.rounded_rectangle(screen_rect, radius=35, fill=screen_color + (255,))
    
    # Draw dynamic island
    island_width = 60
    island_height = 16
    island_x = phone_x + (phone_width - island_width) // 2
    island_y = phone_y + 20
    island_rect = [island_x, island_y, island_x + island_width, island_y + island_height]
    draw.rounded_rectangle(island_rect, radius=8, fill=frame_color + (255,))
    
    # Draw home indicator
    indicator_width = 134
    indicator_height = 5
    indicator_x = phone_x + (phone_width - indicator_width) // 2
    indicator_y = phone_y + phone_height - 20
    indicator_rect = [indicator_x, indicator_y, indicator_x + indicator_width, indicator_y + indicator_height]
    draw.rounded_rectangle(indicator_rect, radius=3, fill=(255, 255, 255, 76))
    
    # Draw app icons on screen
    icon_size = 24
    icon_margin = 8
    icons_per_row = 4
    start_x = phone_x + 30
    start_y = phone_y + 60
    
    # App colors
    app_colors = [
        (76, 175, 80),   # Green (Phone)
        (33, 150, 243),  # Blue (Messages)
        (158, 158, 158), # Gray (Contacts)
        (244, 67, 54),   # Red (Maps)
        (66, 66, 66),    # Dark (Camera)
        (255, 235, 59),  # Yellow (Photos)
        (156, 39, 176),  # Purple (Music)
        (0, 188, 212),   # Cyan (Weather)
    ]
    
    for i, color in enumerate(app_colors):
        row = i // icons_per_row
        col = i % icons_per_row
        x = start_x + col * (icon_size + icon_margin)
        y = start_y + row * (icon_size + icon_margin)
        
        icon_rect = [x, y, x + icon_size, y + icon_size]
        draw.rounded_rectangle(icon_rect, radius=6, fill=color + (255,))
    
    # Add rarity glow effect
    rarity_colors = {
        'legendary': (255, 215, 0),  # Gold
        'epic': (147, 51, 234),      # Purple
        'rare': (59, 130, 246),      # Blue
        'common': (107, 114, 128)    # Gray
    }
    
    if config['rarity'] in rarity_colors:
        glow_color = rarity_colors[config['rarity']]
        # Draw glow effect around phone
        for i in range(3):
            glow_rect = [
                phone_x - i * 2,
                phone_y - i * 2,
                phone_x + phone_width + i * 2,
                phone_y + phone_height + i * 2
            ]
            alpha = 30 - i * 10
            draw.rounded_rectangle(glow_rect, radius=45 + i * 2, outline=glow_color + (alpha,), width=2)
    
    # Add text labels
    try:
        # Try to use a better font
        font_title = ImageFont.truetype("arial.ttf", 20)
        font_subtitle = ImageFont.truetype("arial.ttf", 16)
    except:
        # Fallback to default font
        font_title = ImageFont.load_default()
        font_subtitle = ImageFont.load_default()
    
    # Phone name
    text_y = phone_y + phone_height + 20
    bbox = draw.textbbox((0, 0), config['name'], font=font_title)
    text_width = bbox[2] - bbox[0]
    text_x = (img_size[0] - text_width) // 2
    draw.text((text_x, text_y), config['name'], fill=(255, 255, 255, 255), font=font_title)
    
    # Color name
    text_y += 25
    bbox = draw.textbbox((0, 0), config['color'], font=font_subtitle)
    text_width = bbox[2] - bbox[0]
    text_x = (img_size[0] - text_width) // 2
    draw.text((text_x, text_y), config['color'], fill=(170, 170, 170, 255), font=font_subtitle)
    
    return img

def main():
    """Generate all phone images"""
    # Create output directory
    output_dir = 'inventory_images'
    os.makedirs(output_dir, exist_ok=True)
    
    print("Generating phone inventory images...")
    
    for phone_id, config in PHONE_CONFIGS.items():
        print(f"Creating {phone_id}...")
        img = create_phone_image(phone_id, config)
        
        # Save as PNG
        output_path = os.path.join(output_dir, f"{phone_id}.png")
        img.save(output_path, 'PNG')
        
        print(f"Saved: {output_path}")
    
    print(f"\nGenerated {len(PHONE_CONFIGS)} phone images!")
    print(f"Images saved to: {output_dir}/")

if __name__ == "__main__":
    main()