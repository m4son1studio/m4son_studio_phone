-- Client-side Phone Variants
local currentPhoneVariant = 'iphone_15_pro_max_black'
local phoneVariantChanged = false

-- Set phone variant
RegisterNetEvent('phone:client:setPhoneVariant', function(phoneId)
    if Config.PhoneColors[phoneId] then
        currentPhoneVariant = phoneId
        phoneVariantChanged = true
        
        -- Update phone UI with new colors
        if phoneOpen then
            UpdatePhoneColors()
        end
        
        print('^2[M4SON1 Phone]^0 Phone variant set to: ' .. phoneId)
    end
end)

-- Update phone colors in UI
function UpdatePhoneColors()
    if not Config.PhoneColors[currentPhoneVariant] then return end
    
    local phoneConfig = Config.PhoneColors[currentPhoneVariant]
    
    -- Send color update to NUI
    SendNUIMessage({
        action = 'updatePhoneColors',
        frameColor = phoneConfig.frameColor,
        buttonColor = phoneConfig.buttonColor
    })
end

-- Get current phone variant
function GetCurrentPhoneVariant()
    return currentPhoneVariant
end

-- Request phone variant from server
function RequestPhoneVariant()
    TriggerServerEvent('phone:server:getPhoneVariant')
end

-- Initialize phone variant
AddEventHandler('phone:client:playerLoaded', function()
    RequestPhoneVariant()
end)

-- Export functions
exports('GetCurrentPhoneVariant', GetCurrentPhoneVariant)
exports('SetPhoneVariant', function(phoneId)
    TriggerEvent('phone:client:setPhoneVariant', phoneId)
end)