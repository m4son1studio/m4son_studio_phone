local phoneOpen = false
local phoneAnimating = false
local currentApp = 'home'

-- Initialize phone when player loads
AddEventHandler('phone:client:playerLoaded', function()
    print('^2[M4SON1 Phone]^0 Player loaded, initializing phone...')
    TriggerServerEvent('phone:server:initialize')
end)

-- Key mapping for F1
RegisterKeyMapping('phone_toggle', 'Toggle Phone', 'keyboard', Config.OpenKey)

-- Command handler
RegisterCommand('phone_toggle', function()
    TogglePhone()
end, false)

-- Toggle phone function
function TogglePhone()
    if phoneAnimating then return end
    
    phoneAnimating = true
    
    if phoneOpen then
        ClosePhone()
    else
        OpenPhone()
    end
    
    SetTimeout(Config.Animations.OpenDuration, function()
        phoneAnimating = false
    end)
end

-- Open phone
function OpenPhone()
    if phoneOpen then return end
    
    phoneOpen = true
    
    -- Disable game controls
    SetNuiFocus(true, true)
    
    -- Send NUI message
    SendNUIMessage({
        action = 'openPhone',
        playerData = GetPlayerData(),
        framework = exports.m4son1_studio_phone:GetFramework()
    })
    
    -- Play sound
    if Config.EnableSounds then
        PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', false)
    end
    
    -- Disable certain controls
    CreateThread(function()
        while phoneOpen do
            Wait(0)
            DisableControlAction(0, 1, true) -- LookLeftRight
            DisableControlAction(0, 2, true) -- LookUpDown
            DisableControlAction(0, 24, true) -- Attack
            DisableControlAction(0, 257, true) -- Attack2
            DisableControlAction(0, 25, true) -- Aim
            DisableControlAction(0, 263, true) -- MeleeAttack1
            DisableControlAction(0, 37, true) -- SelectWeapon
            DisableControlAction(0, 44, true) -- Cover
            DisableControlAction(0, 45, true) -- Reload
            DisableControlAction(0, 140, true) -- MeleeAttackLight
            DisableControlAction(0, 141, true) -- MeleeAttackHeavy
            DisableControlAction(0, 142, true) -- MeleeAttackAlternate
            DisableControlAction(0, 143, true) -- MeleeBlock
        end
    end)
end

-- Close phone
function ClosePhone()
    if not phoneOpen then return end
    
    phoneOpen = false
    currentApp = 'home'
    
    -- Re-enable game controls
    SetNuiFocus(false, false)
    
    -- Send NUI message
    SendNUIMessage({
        action = 'closePhone'
    })
    
    -- Play sound
    if Config.EnableSounds then
        PlaySoundFrontend(-1, 'BACK', 'HUD_FRONTEND_DEFAULT_SOUNDSET', false)
    end
end

-- NUI Callbacks
RegisterNUICallback('closePhone', function(data, cb)
    ClosePhone()
    cb('ok')
end)

RegisterNUICallback('openApp', function(data, cb)
    local app = data.app
    currentApp = app
    
    -- Request app data from server
    TriggerServerEvent('phone:server:getAppData', app)
    
    cb('ok')
end)

RegisterNUICallback('appAction', function(data, cb)
    local app = data.app
    local action = data.action
    local appData = data.data
    
    -- Send action to server
    TriggerServerEvent('phone:server:appAction', app, action, appData)
    
    cb('ok')
end)

-- Server events
RegisterNetEvent('phone:client:receiveAppData', function(app, data)
    SendNUIMessage({
        action = 'receiveAppData',
        app = app,
        data = data
    })
end)

RegisterNetEvent('phone:client:receiveNotification', function(notification)
    if not Config.EnableNotifications then return end
    
    SendNUIMessage({
        action = 'receiveNotification',
        notification = notification
    })
    
    -- Play notification sound
    if Config.EnableSounds then
        PlaySoundFrontend(-1, 'TEXT_ARRIVE_TONE', 'PHONE_SOUNDSET_DEFAULT', false)
    end
end)

RegisterNetEvent('phone:client:updateAppData', function(app, data)
    SendNUIMessage({
        action = 'updateAppData',
        app = app,
        data = data
    })
end)

-- Phone call system
RegisterNetEvent('phone:client:receiveCall', function(callData)
    SendNUIMessage({
        action = 'receiveCall',
        callData = callData
    })
end)

RegisterNetEvent('phone:client:callEnded', function()
    SendNUIMessage({
        action = 'callEnded'
    })
end)

-- Export functions
exports('IsPhoneOpen', function()
    return phoneOpen
end)

exports('OpenPhone', OpenPhone)
exports('ClosePhone', ClosePhone)
exports('GetCurrentApp', function()
    return currentApp
end)

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        if phoneOpen then
            ClosePhone()
        end
    end
end)
