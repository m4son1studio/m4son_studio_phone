local Framework = nil
local PlayerData = {}

-- Framework Detection
CreateThread(function()
    if Config.Framework == 'auto' then
        -- Auto-detect framework
        if GetResourceState('es_extended') == 'started' then
            Framework = 'ESX'
        elseif GetResourceState('qb-core') == 'started' then
            Framework = 'QBCore'
        else
            Framework = 'Standalone'
        end
    else
        Framework = Config.Framework:upper()
    end
    
    -- Initialize framework
    if Framework == 'ESX' then
        InitializeESX()
    elseif Framework == 'QBCORE' then
        InitializeQBCore()
    end
    
    print('^2[M4SON1 Phone]^0 Framework detected: ' .. Framework)
end)

-- ESX Initialization
function InitializeESX()
    ESX = exports['es_extended']:getSharedObject()
    
    RegisterNetEvent('esx:playerLoaded', function(xPlayer)
        PlayerData = xPlayer
        TriggerEvent('phone:client:playerLoaded')
    end)
    
    RegisterNetEvent('esx:setJob', function(job)
        PlayerData.job = job
        TriggerEvent('phone:client:jobUpdated', job)
    end)
end

-- QBCore Initialization
function InitializeQBCore()
    QBCore = exports['qb-core']:GetCoreObject()
    
    RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
        PlayerData = QBCore.Functions.GetPlayerData()
        TriggerEvent('phone:client:playerLoaded')
    end)
    
    RegisterNetEvent('QBCore:Client:OnJobUpdate', function(JobInfo)
        PlayerData.job = JobInfo
        TriggerEvent('phone:client:jobUpdated', JobInfo)
    end)
end

-- Get Player Data
function GetPlayerData()
    if Framework == 'ESX' then
        return ESX.GetPlayerData()
    elseif Framework == 'QBCORE' then
        return QBCore.Functions.GetPlayerData()
    else
        return PlayerData
    end
end

-- Get Player Money
function GetPlayerMoney(moneyType)
    moneyType = moneyType or 'cash'
    
    if Framework == 'ESX' then
        return ESX.GetPlayerData().money or 0
    elseif Framework == 'QBCORE' then
        return QBCore.Functions.GetPlayerData().money[moneyType] or 0
    else
        return 0
    end
end

-- Show Notification
function ShowNotification(message, type, duration)
    if Framework == 'ESX' then
        ESX.ShowNotification(message, type, duration)
    elseif Framework == 'QBCORE' then
        QBCore.Functions.Notify(message, type, duration)
    else
        -- Fallback notification
        TriggerEvent('chat:addMessage', {
            color = {255, 255, 255},
            multiline = true,
            args = {'Phone', message}
        })
    end
end

-- Export functions
exports('GetFramework', function()
    return Framework
end)

exports('GetPlayerData', GetPlayerData)
exports('GetPlayerMoney', GetPlayerMoney)
exports('ShowNotification', ShowNotification)
