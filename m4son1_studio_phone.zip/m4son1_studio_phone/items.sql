-- Phone Items for ESX/QBCore Inventory Systems
-- Add these items to your framework's items database

-- For ESX (items table)
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
('iphone_15_pro_max_black', 'iPhone 15 Pro Max - Black Titanium', 1, 0, 1),
('iphone_15_pro_max_white', 'iPhone 15 Pro Max - White Titanium', 1, 0, 1),
('iphone_15_pro_max_blue', 'iPhone 15 Pro Max - Blue Titanium', 1, 0, 1),
('iphone_15_pro_max_natural', 'iPhone 15 Pro Max - Natural Titanium', 1, 0, 1),
('iphone_15_pro_black', 'iPhone 15 Pro - Black Titanium', 1, 0, 1),
('iphone_15_pro_white', 'iPhone 15 Pro - White Titanium', 1, 0, 1),
('iphone_15_pro_blue', 'iPhone 15 Pro - Blue Titanium', 1, 0, 1),
('iphone_15_pro_natural', 'iPhone 15 Pro - Natural Titanium', 1, 0, 1),
('iphone_15_pink', 'iPhone 15 - Pink', 1, 0, 1),
('iphone_15_yellow', 'iPhone 15 - Yellow', 1, 0, 1),
('iphone_15_green', 'iPhone 15 - Green', 1, 0, 1),
('iphone_15_blue', 'iPhone 15 - Blue', 1, 0, 1),
('iphone_15_black', 'iPhone 15 - Black', 1, 0, 1);

-- For QBCore (qb-core/shared/items.lua)
-- Add these to your QBCore items table:

--[[
	-- iPhone 15 Pro Max Series
	['iphone_15_pro_max_black'] = {
		name = 'iphone_15_pro_max_black',
		label = 'iPhone 15 Pro Max - Black Titanium',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_pro_max_black.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'Latest iPhone 15 Pro Max in Black Titanium. Premium smartphone with advanced features.'
	},
	['iphone_15_pro_max_white'] = {
		name = 'iphone_15_pro_max_white',
		label = 'iPhone 15 Pro Max - White Titanium',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_pro_max_white.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'Latest iPhone 15 Pro Max in White Titanium. Premium smartphone with advanced features.'
	},
	['iphone_15_pro_max_blue'] = {
		name = 'iphone_15_pro_max_blue',
		label = 'iPhone 15 Pro Max - Blue Titanium',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_pro_max_blue.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'Latest iPhone 15 Pro Max in Blue Titanium. Premium smartphone with advanced features.'
	},
	['iphone_15_pro_max_natural'] = {
		name = 'iphone_15_pro_max_natural',
		label = 'iPhone 15 Pro Max - Natural Titanium',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_pro_max_natural.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'Latest iPhone 15 Pro Max in Natural Titanium. Premium smartphone with advanced features.'
	},
	
	-- iPhone 15 Pro Series
	['iphone_15_pro_black'] = {
		name = 'iphone_15_pro_black',
		label = 'iPhone 15 Pro - Black Titanium',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_pro_black.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'iPhone 15 Pro in Black Titanium. Professional smartphone with advanced camera system.'
	},
	['iphone_15_pro_white'] = {
		name = 'iphone_15_pro_white',
		label = 'iPhone 15 Pro - White Titanium',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_pro_white.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'iPhone 15 Pro in White Titanium. Professional smartphone with advanced camera system.'
	},
	['iphone_15_pro_blue'] = {
		name = 'iphone_15_pro_blue',
		label = 'iPhone 15 Pro - Blue Titanium',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_pro_blue.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'iPhone 15 Pro in Blue Titanium. Professional smartphone with advanced camera system.'
	},
	['iphone_15_pro_natural'] = {
		name = 'iphone_15_pro_natural',
		label = 'iPhone 15 Pro - Natural Titanium',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_pro_natural.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'iPhone 15 Pro in Natural Titanium. Professional smartphone with advanced camera system.'
	},
	
	-- iPhone 15 Series
	['iphone_15_pink'] = {
		name = 'iphone_15_pink',
		label = 'iPhone 15 - Pink',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_pink.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'iPhone 15 in Pink. Modern smartphone with excellent performance.'
	},
	['iphone_15_yellow'] = {
		name = 'iphone_15_yellow',
		label = 'iPhone 15 - Yellow',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_yellow.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'iPhone 15 in Yellow. Modern smartphone with excellent performance.'
	},
	['iphone_15_green'] = {
		name = 'iphone_15_green',
		label = 'iPhone 15 - Green',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_green.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'iPhone 15 in Green. Modern smartphone with excellent performance.'
	},
	['iphone_15_blue'] = {
		name = 'iphone_15_blue',
		label = 'iPhone 15 - Blue',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_blue.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'iPhone 15 in Blue. Modern smartphone with excellent performance.'
	},
	['iphone_15_black'] = {
		name = 'iphone_15_black',
		label = 'iPhone 15 - Black',
		weight = 1000,
		type = 'item',
		image = 'iphone_15_black.png',
		unique = true,
		useable = true,
		shouldClose = true,
		combinable = nil,
		description = 'iPhone 15 in Black. Modern smartphone with excellent performance.'
	},
--]]

-- Shop Configuration for Phone Store
-- Add this to your server's shop system

--[[
Phone Store Items:
- iPhone 15 Pro Max - Black Titanium: $1,200
- iPhone 15 Pro Max - White Titanium: $1,200
- iPhone 15 Pro Max - Blue Titanium: $1,200
- iPhone 15 Pro Max - Natural Titanium: $1,200
- iPhone 15 Pro - Black Titanium: $1,000
- iPhone 15 Pro - White Titanium: $1,000
- iPhone 15 Pro - Blue Titanium: $1,000
- iPhone 15 Pro - Natural Titanium: $1,000
- iPhone 15 - Pink: $800
- iPhone 15 - Yellow: $800
- iPhone 15 - Green: $800
- iPhone 15 - Blue: $800
- iPhone 15 - Black: $800
--]]