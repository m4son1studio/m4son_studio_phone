-- M4SON1 Studio Phone Database Schema
-- Compatible with SQLite and MySQL

-- Users table to store phone user data
CREATE TABLE IF NOT EXISTS phone_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    identifier VARCHAR(50) NOT NULL UNIQUE,
    phone_number VARCHAR(20) NOT NULL UNIQUE,
    background VARCHAR(100) DEFAULT 'default',
    ringtone VARCHAR(100) DEFAULT 'default',
    notification_sound VARCHAR(100) DEFAULT 'default',
    settings TEXT DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contacts table to store user contacts
CREATE TABLE IF NOT EXISTS phone_contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    number VARCHAR(20) NOT NULL,
    avatar VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Messages table to store text messages
CREATE TABLE IF NOT EXISTS phone_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_identifier VARCHAR(50) NOT NULL,
    receiver_identifier VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    read_status BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE,
    FOREIGN KEY (receiver_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Calls table to store call history
CREATE TABLE IF NOT EXISTS phone_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    caller_identifier VARCHAR(50) NOT NULL,
    receiver_identifier VARCHAR(50) NOT NULL,
    duration INTEGER DEFAULT 0,
    call_type VARCHAR(20) DEFAULT 'voice',
    status VARCHAR(20) DEFAULT 'missed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (caller_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE,
    FOREIGN KEY (receiver_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Photos table to store user photos
CREATE TABLE IF NOT EXISTS phone_photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    filename VARCHAR(255) NOT NULL,
    url VARCHAR(500) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Notes table to store user notes
CREATE TABLE IF NOT EXISTS phone_notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Banking table to store user bank accounts
CREATE TABLE IF NOT EXISTS phone_banking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    account_number VARCHAR(50) NOT NULL,
    balance DECIMAL(15,2) DEFAULT 0.00,
    account_type VARCHAR(20) DEFAULT 'checking',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Banking transactions table
CREATE TABLE IF NOT EXISTS phone_banking_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    transaction_type VARCHAR(20) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES phone_banking(id) ON DELETE CASCADE
);

-- Calendar events table
CREATE TABLE IF NOT EXISTS phone_calendar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    start_date TIMESTAMP NOT NULL,
    end_date TIMESTAMP NOT NULL,
    all_day BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Emails table to store emails
CREATE TABLE IF NOT EXISTS phone_emails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    sender VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    read_status BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Music playlists table
CREATE TABLE IF NOT EXISTS phone_music_playlists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Music tracks table
CREATE TABLE IF NOT EXISTS phone_music_tracks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    playlist_id INTEGER NOT NULL,
    title VARCHAR(255) NOT NULL,
    artist VARCHAR(255) NOT NULL,
    url VARCHAR(500) NOT NULL,
    duration INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (playlist_id) REFERENCES phone_music_playlists(id) ON DELETE CASCADE
);

-- App installations table
CREATE TABLE IF NOT EXISTS phone_app_installations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    app_name VARCHAR(100) NOT NULL,
    app_version VARCHAR(20) DEFAULT '1.0.0',
    installed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Notifications table
CREATE TABLE IF NOT EXISTS phone_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    app VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    icon VARCHAR(50) DEFAULT 'bell',
    type VARCHAR(20) DEFAULT 'info',
    read_status BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- GPS locations table (for maps/tracking)
CREATE TABLE IF NOT EXISTS phone_gps_locations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    name VARCHAR(255),
    x FLOAT NOT NULL,
    y FLOAT NOT NULL,
    z FLOAT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Weather data cache table
CREATE TABLE IF NOT EXISTS phone_weather_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    location VARCHAR(255) NOT NULL,
    temperature INTEGER NOT NULL,
    condition VARCHAR(100) NOT NULL,
    humidity INTEGER NOT NULL,
    wind_speed INTEGER NOT NULL,
    forecast_data TEXT,
    cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Alarms table
CREATE TABLE IF NOT EXISTS phone_alarms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_identifier VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    time TIME NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    repeat_days VARCHAR(20) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier) ON DELETE CASCADE
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_phone_users_identifier ON phone_users(identifier);
CREATE INDEX IF NOT EXISTS idx_phone_users_phone_number ON phone_users(phone_number);
CREATE INDEX IF NOT EXISTS idx_phone_contacts_owner ON phone_contacts(owner_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_messages_sender ON phone_messages(sender_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_messages_receiver ON phone_messages(receiver_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_calls_caller ON phone_calls(caller_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_calls_receiver ON phone_calls(receiver_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_photos_owner ON phone_photos(owner_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_notes_owner ON phone_notes(owner_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_banking_owner ON phone_banking(owner_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_banking_transactions_account ON phone_banking_transactions(account_id);
CREATE INDEX IF NOT EXISTS idx_phone_calendar_owner ON phone_calendar(owner_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_emails_owner ON phone_emails(owner_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_notifications_owner ON phone_notifications(owner_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_gps_locations_owner ON phone_gps_locations(owner_identifier);
CREATE INDEX IF NOT EXISTS idx_phone_alarms_owner ON phone_alarms(owner_identifier);

-- Insert default data (optional)
-- This section can be uncommented if you want to pre-populate with sample data

-- Default ringtones
INSERT OR IGNORE INTO phone_users (identifier, phone_number, settings) VALUES 
('default_user', '1234567890', '{"notifications": true, "sounds": true, "vibration": true}');

-- Default weather data for Los Santos
INSERT OR IGNORE INTO phone_weather_cache (location, temperature, condition, humidity, wind_speed, forecast_data) VALUES 
('Los Santos', 25, 'Sunny', 45, 12, '{"forecast": [{"day": "Today", "high": 28, "low": 18, "condition": "Sunny"}]}');

-- Create triggers for updating timestamps
CREATE TRIGGER IF NOT EXISTS update_phone_users_timestamp 
    AFTER UPDATE ON phone_users 
    BEGIN 
        UPDATE phone_users SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

CREATE TRIGGER IF NOT EXISTS update_phone_notes_timestamp 
    AFTER UPDATE ON phone_notes 
    BEGIN 
        UPDATE phone_notes SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;

-- Create views for common queries
CREATE VIEW IF NOT EXISTS phone_contact_messages AS
SELECT 
    m.*,
    c1.name as sender_name,
    c2.name as receiver_name
FROM phone_messages m
LEFT JOIN phone_contacts c1 ON m.sender_identifier = c1.owner_identifier
LEFT JOIN phone_contacts c2 ON m.receiver_identifier = c2.owner_identifier;

CREATE VIEW IF NOT EXISTS phone_call_history AS
SELECT 
    c.*,
    u1.phone_number as caller_number,
    u2.phone_number as receiver_number
FROM phone_calls c
LEFT JOIN phone_users u1 ON c.caller_identifier = u1.identifier
LEFT JOIN phone_users u2 ON c.receiver_identifier = u2.identifier;

-- Database schema version
CREATE TABLE IF NOT EXISTS phone_schema_version (
    version INTEGER PRIMARY KEY,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT OR REPLACE INTO phone_schema_version (version) VALUES (1);
