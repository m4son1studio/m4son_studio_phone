-- Server Events
RegisterNetEvent('phone:server:initialize', function()
    local source = source
    local identifier = exports.m4son1_studio_phone:GetPlayerIdentifier(source)
    
    if not identifier then
        print('^1[M4SON1 Phone]^0 Could not get player identifier for source: ' .. source)
        return
    end
    
    -- Check if user exists in database
    local user = PhoneDatabase.GetUser(identifier)
    if not user then
        -- Generate phone number
        local phoneNumber = GeneratePhoneNumber()
        PhoneDatabase.CreateUser(identifier, phoneNumber)
        
        -- Send welcome notification
        TriggerClientEvent('phone:client:receiveNotification', source, {
            app = 'system',
            title = 'Welcome to M4SON1 Phone!',
            message = 'Your phone number is: ' .. phoneNumber,
            icon = 'phone',
            type = 'success'
        })
    end
end)

RegisterNetEvent('phone:server:getAppData', function(app)
    local source = source
    local identifier = exports.m4son1_studio_phone:GetPlayerIdentifier(source)
    
    if not identifier then return end
    
    local data = {}
    
    -- Get app-specific data
    if app == 'contacts' then
        data = PhoneDatabase.GetContacts(identifier)
    elseif app == 'messages' then
        data = PhoneDatabase.GetMessages(identifier)
    elseif app == 'phone' then
        data = PhoneDatabase.GetCalls(identifier)
    elseif app == 'photos' then
        data = PhoneDatabase.GetPhotos(identifier)
    elseif app == 'notes' then
        data = PhoneDatabase.GetNotes(identifier)
    elseif app == 'banking' then
        data = GetBankingData(identifier)
    elseif app == 'calendar' then
        data = PhoneDatabase.GetCalendarEvents(identifier)
    elseif app == 'email' then
        data = PhoneDatabase.GetEmails(identifier)
    elseif app == 'weather' then
        data = GetWeatherData()
    elseif app == 'maps' then
        data = GetPlayerLocation(source)
    end
    
    TriggerClientEvent('phone:client:receiveAppData', source, app, data)
end)

RegisterNetEvent('phone:server:appAction', function(app, action, data)
    local source = source
    local identifier = exports.m4son1_studio_phone:GetPlayerIdentifier(source)
    
    if not identifier then return end
    
    -- Handle app-specific actions
    if app == 'contacts' then
        HandleContactsAction(source, identifier, action, data)
    elseif app == 'messages' then
        HandleMessagesAction(source, identifier, action, data)
    elseif app == 'phone' then
        HandlePhoneAction(source, identifier, action, data)
    elseif app == 'photos' then
        HandlePhotosAction(source, identifier, action, data)
    elseif app == 'notes' then
        HandleNotesAction(source, identifier, action, data)
    elseif app == 'banking' then
        HandleBankingAction(source, identifier, action, data)
    elseif app == 'calendar' then
        HandleCalendarAction(source, identifier, action, data)
    elseif app == 'email' then
        HandleEmailAction(source, identifier, action, data)
    elseif app == 'camera' then
        HandleCameraAction(source, identifier, action, data)
    end
end)

-- App Action Handlers
function HandleContactsAction(source, identifier, action, data)
    if action == 'add' then
        PhoneDatabase.AddContact(identifier, data.name, data.number, data.avatar)
        TriggerClientEvent('phone:client:updateAppData', source, 'contacts', PhoneDatabase.GetContacts(identifier))
    elseif action == 'update' then
        PhoneDatabase.UpdateContact(data.id, data.name, data.number, data.avatar)
        TriggerClientEvent('phone:client:updateAppData', source, 'contacts', PhoneDatabase.GetContacts(identifier))
    elseif action == 'delete' then
        PhoneDatabase.DeleteContact(data.id)
        TriggerClientEvent('phone:client:updateAppData', source, 'contacts', PhoneDatabase.GetContacts(identifier))
    end
end

function HandleMessagesAction(source, identifier, action, data)
    if action == 'send' then
        -- Find receiver by phone number
        local receiver = FindPlayerByPhoneNumber(data.number)
        if receiver then
            PhoneDatabase.SendMessage(identifier, receiver.identifier, data.message)
            
            -- Send notification to receiver
            TriggerClientEvent('phone:client:receiveNotification', receiver.source, {
                app = 'messages',
                title = 'New Message',
                message = data.message,
                icon = 'message-circle',
                type = 'info'
            })
        end
        
        TriggerClientEvent('phone:client:updateAppData', source, 'messages', PhoneDatabase.GetMessages(identifier))
    elseif action == 'markRead' then
        PhoneDatabase.MarkMessageAsRead(data.messageId)
    end
end

function HandlePhoneAction(source, identifier, action, data)
    if action == 'call' then
        local receiver = FindPlayerByPhoneNumber(data.number)
        if receiver then
            -- Send call notification to receiver
            TriggerClientEvent('phone:client:receiveCall', receiver.source, {
                caller = identifier,
                number = data.number,
                type = 'incoming'
            })
            
            -- Send call notification to caller
            TriggerClientEvent('phone:client:receiveCall', source, {
                receiver = receiver.identifier,
                number = data.number,
                type = 'outgoing'
            })
        else
            -- Number not found or player offline
            TriggerClientEvent('phone:client:receiveNotification', source, {
                app = 'phone',
                title = 'Call Failed',
                message = 'The number you dialed is not available.',
                icon = 'phone-off',
                type = 'error'
            })
        end
    elseif action == 'endCall' then
        PhoneDatabase.AddCall(identifier, data.receiverIdentifier, data.duration, 'voice', 'completed')
        TriggerClientEvent('phone:client:callEnded', source)
        
        -- Notify other party
        local receiver = FindPlayerByIdentifier(data.receiverIdentifier)
        if receiver then
            TriggerClientEvent('phone:client:callEnded', receiver.source)
        end
    end
end

function HandlePhotosAction(source, identifier, action, data)
    if action == 'add' then
        PhoneDatabase.AddPhoto(identifier, data.filename, data.url)
        TriggerClientEvent('phone:client:updateAppData', source, 'photos', PhoneDatabase.GetPhotos(identifier))
    elseif action == 'delete' then
        PhoneDatabase.DeletePhoto(data.id)
        TriggerClientEvent('phone:client:updateAppData', source, 'photos', PhoneDatabase.GetPhotos(identifier))
    end
end

function HandleNotesAction(source, identifier, action, data)
    if action == 'add' then
        PhoneDatabase.AddNote(identifier, data.title, data.content)
        TriggerClientEvent('phone:client:updateAppData', source, 'notes', PhoneDatabase.GetNotes(identifier))
    elseif action == 'update' then
        PhoneDatabase.UpdateNote(data.id, data.title, data.content)
        TriggerClientEvent('phone:client:updateAppData', source, 'notes', PhoneDatabase.GetNotes(identifier))
    elseif action == 'delete' then
        PhoneDatabase.DeleteNote(data.id)
        TriggerClientEvent('phone:client:updateAppData', source, 'notes', PhoneDatabase.GetNotes(identifier))
    end
end

function HandleBankingAction(source, identifier, action, data)
    if action == 'transfer' then
        local player = exports.m4son1_studio_phone:GetPlayer(source)
        if player then
            local currentMoney = exports.m4son1_studio_phone:GetPlayerMoney(source, 'bank')
            if currentMoney >= data.amount then
                exports.m4son1_studio_phone:RemovePlayerMoney(source, data.amount, 'bank')
                
                -- Add to receiver if they're online
                local receiver = FindPlayerByPhoneNumber(data.receiverNumber)
                if receiver then
                    exports.m4son1_studio_phone:AddPlayerMoney(receiver.source, data.amount, 'bank')
                end
                
                exports.m4son1_studio_phone:ShowNotification(source, 'Transfer completed successfully', 'success')
            else
                exports.m4son1_studio_phone:ShowNotification(source, 'Insufficient funds', 'error')
            end
        end
    end
end

function HandleCalendarAction(source, identifier, action, data)
    if action == 'add' then
        PhoneDatabase.AddCalendarEvent(identifier, data.title, data.description, data.startDate, data.endDate, data.allDay)
        TriggerClientEvent('phone:client:updateAppData', source, 'calendar', PhoneDatabase.GetCalendarEvents(identifier))
    end
end

function HandleEmailAction(source, identifier, action, data)
    if action == 'send' then
        -- Find receiver by phone number or email
        local receiver = FindPlayerByPhoneNumber(data.to)
        if receiver then
            PhoneDatabase.AddEmail(receiver.identifier, data.from, data.subject, data.body)
            
            -- Send notification
            TriggerClientEvent('phone:client:receiveNotification', receiver.source, {
                app = 'email',
                title = 'New Email',
                message = 'From: ' .. data.from,
                icon = 'mail',
                type = 'info'
            })
        end
    elseif action == 'markRead' then
        PhoneDatabase.MarkEmailAsRead(data.emailId)
    end
end

function HandleCameraAction(source, identifier, action, data)
    if action == 'takePhoto' then
        -- Generate photo URL (this would typically involve image processing)
        local photoUrl = 'https://example.com/photos/' .. identifier .. '_' .. os.time() .. '.jpg'
        local filename = 'photo_' .. os.time() .. '.jpg'
        
        PhoneDatabase.AddPhoto(identifier, filename, photoUrl)
        TriggerClientEvent('phone:client:updateAppData', source, 'photos', PhoneDatabase.GetPhotos(identifier))
        
        TriggerClientEvent('phone:client:receiveNotification', source, {
            app = 'camera',
            title = 'Photo Saved',
            message = 'Photo saved to gallery',
            icon = 'camera',
            type = 'success'
        })
    end
end

-- Helper Functions
function GeneratePhoneNumber()
    local numbers = {}
    for i = 1, 10 do
        table.insert(numbers, math.random(0, 9))
    end
    return table.concat(numbers)
end

function FindPlayerByPhoneNumber(phoneNumber)
    local players = GetPlayers()
    for _, playerId in ipairs(players) do
        local identifier = exports.m4son1_studio_phone:GetPlayerIdentifier(playerId)
        if identifier then
            local user = PhoneDatabase.GetUser(identifier)
            if user and user.phone_number == phoneNumber then
                return {
                    source = playerId,
                    identifier = identifier,
                    user = user
                }
            end
        end
    end
    return nil
end

function FindPlayerByIdentifier(identifier)
    local players = GetPlayers()
    for _, playerId in ipairs(players) do
        local playerIdentifier = exports.m4son1_studio_phone:GetPlayerIdentifier(playerId)
        if playerIdentifier == identifier then
            return {
                source = playerId,
                identifier = identifier
            }
        end
    end
    return nil
end

function GetBankingData(identifier)
    local bankingData = PhoneDatabase.GetBankingData(identifier)
    for _, account in ipairs(bankingData) do
        account.transactions = PhoneDatabase.GetBankingTransactions(account.id)
    end
    return bankingData
end

function GetWeatherData()
    -- This would typically connect to a weather API
    return {
        location = 'Los Santos',
        temperature = math.random(20, 35),
        condition = 'Sunny',
        humidity = math.random(30, 70),
        windSpeed = math.random(5, 20),
        forecast = {
            {day = 'Today', high = 28, low = 18, condition = 'Sunny'},
            {day = 'Tomorrow', high = 25, low = 16, condition = 'Cloudy'},
            {day = 'Wednesday', high = 22, low = 14, condition = 'Rainy'},
            {day = 'Thursday', high = 26, low = 17, condition = 'Partly Cloudy'},
            {day = 'Friday', high = 29, low = 19, condition = 'Sunny'}
        }
    }
end

function GetPlayerLocation(source)
    local ped = GetPlayerPed(source)
    local coords = GetEntityCoords(ped)
    return {
        x = coords.x,
        y = coords.y,
        z = coords.z
    }
end

-- Cleanup on resource stop
AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        print('^2[M4SON1 Phone]^0 Resource stopped, cleaning up...')
    end
end)
