local Database = {}

-- Initialize database
function Database.Initialize()
    -- Create tables if they don't exist
    local queries = {
        [[
        CREATE TABLE IF NOT EXISTS phone_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            identifier VARCHAR(50) NOT NULL UNIQUE,
            phone_number VARCHAR(20) NOT NULL UNIQUE,
            background VARCHAR(100) DEFAULT 'default',
            ringtone VARCHAR(100) DEFAULT 'default',
            notification_sound VARCHAR(100) DEFAULT 'default',
            settings TEXT DEFAULT '{}',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ]],
        [[
        CREATE TABLE IF NOT EXISTS phone_contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_identifier VARCHAR(50) NOT NULL,
            name VARCHAR(100) NOT NULL,
            number VARCHAR(20) NOT NULL,
            avatar VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier)
        )
        ]],
        [[
        CREATE TABLE IF NOT EXISTS phone_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_identifier VARCHAR(50) NOT NULL,
            receiver_identifier VARCHAR(50) NOT NULL,
            message TEXT NOT NULL,
            read_status BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ]],
        [[
        CREATE TABLE IF NOT EXISTS phone_calls (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            caller_identifier VARCHAR(50) NOT NULL,
            receiver_identifier VARCHAR(50) NOT NULL,
            duration INTEGER DEFAULT 0,
            call_type VARCHAR(20) DEFAULT 'voice',
            status VARCHAR(20) DEFAULT 'missed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ]],
        [[
        CREATE TABLE IF NOT EXISTS phone_photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_identifier VARCHAR(50) NOT NULL,
            filename VARCHAR(255) NOT NULL,
            url VARCHAR(500) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier)
        )
        ]],
        [[
        CREATE TABLE IF NOT EXISTS phone_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_identifier VARCHAR(50) NOT NULL,
            title VARCHAR(255) NOT NULL,
            content TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier)
        )
        ]],
        [[
        CREATE TABLE IF NOT EXISTS phone_banking (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_identifier VARCHAR(50) NOT NULL,
            account_number VARCHAR(50) NOT NULL,
            balance DECIMAL(15,2) DEFAULT 0.00,
            account_type VARCHAR(20) DEFAULT 'checking',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier)
        )
        ]],
        [[
        CREATE TABLE IF NOT EXISTS phone_banking_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_id INTEGER NOT NULL,
            transaction_type VARCHAR(20) NOT NULL,
            amount DECIMAL(15,2) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (account_id) REFERENCES phone_banking(id)
        )
        ]],
        [[
        CREATE TABLE IF NOT EXISTS phone_calendar (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_identifier VARCHAR(50) NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            start_date TIMESTAMP NOT NULL,
            end_date TIMESTAMP NOT NULL,
            all_day BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier)
        )
        ]],
        [[
        CREATE TABLE IF NOT EXISTS phone_emails (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_identifier VARCHAR(50) NOT NULL,
            sender VARCHAR(255) NOT NULL,
            subject VARCHAR(255) NOT NULL,
            body TEXT NOT NULL,
            read_status BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_identifier) REFERENCES phone_users(identifier)
        )
        ]]
    }
    
    for _, query in ipairs(queries) do
        MySQL.Async.execute(query, {}, function(result)
            if result then
                print('^2[M4SON1 Phone]^0 Database table created successfully')
            else
                print('^1[M4SON1 Phone]^0 Error creating database table')
            end
        end)
    end
end

-- User Management
function Database.GetUser(identifier)
    local result = MySQL.Sync.fetchAll('SELECT * FROM phone_users WHERE identifier = ?', {identifier})
    return result[1] or nil
end

function Database.CreateUser(identifier, phoneNumber)
    MySQL.Async.execute('INSERT INTO phone_users (identifier, phone_number) VALUES (?, ?)', {
        identifier, phoneNumber
    }, function(result)
        if result then
            print('^2[M4SON1 Phone]^0 User created: ' .. identifier)
        end
    end)
end

function Database.UpdateUserSettings(identifier, settings)
    MySQL.Async.execute('UPDATE phone_users SET settings = ?, updated_at = CURRENT_TIMESTAMP WHERE identifier = ?', {
        json.encode(settings), identifier
    })
end

-- Contacts Management
function Database.GetContacts(identifier)
    return MySQL.Sync.fetchAll('SELECT * FROM phone_contacts WHERE owner_identifier = ? ORDER BY name ASC', {identifier})
end

function Database.AddContact(identifier, name, number, avatar)
    MySQL.Async.execute('INSERT INTO phone_contacts (owner_identifier, name, number, avatar) VALUES (?, ?, ?, ?)', {
        identifier, name, number, avatar
    })
end

function Database.UpdateContact(contactId, name, number, avatar)
    MySQL.Async.execute('UPDATE phone_contacts SET name = ?, number = ?, avatar = ? WHERE id = ?', {
        name, number, avatar, contactId
    })
end

function Database.DeleteContact(contactId)
    MySQL.Async.execute('DELETE FROM phone_contacts WHERE id = ?', {contactId})
end

-- Messages Management
function Database.GetMessages(identifier)
    return MySQL.Sync.fetchAll([[
        SELECT m.*, u1.phone_number as sender_number, u2.phone_number as receiver_number
        FROM phone_messages m
        LEFT JOIN phone_users u1 ON m.sender_identifier = u1.identifier
        LEFT JOIN phone_users u2 ON m.receiver_identifier = u2.identifier
        WHERE m.sender_identifier = ? OR m.receiver_identifier = ?
        ORDER BY m.created_at DESC
    ]], {identifier, identifier})
end

function Database.SendMessage(senderIdentifier, receiverIdentifier, message)
    MySQL.Async.execute('INSERT INTO phone_messages (sender_identifier, receiver_identifier, message) VALUES (?, ?, ?)', {
        senderIdentifier, receiverIdentifier, message
    })
end

function Database.MarkMessageAsRead(messageId)
    MySQL.Async.execute('UPDATE phone_messages SET read_status = TRUE WHERE id = ?', {messageId})
end

-- Calls Management
function Database.GetCalls(identifier)
    return MySQL.Sync.fetchAll([[
        SELECT c.*, u1.phone_number as caller_number, u2.phone_number as receiver_number
        FROM phone_calls c
        LEFT JOIN phone_users u1 ON c.caller_identifier = u1.identifier
        LEFT JOIN phone_users u2 ON c.receiver_identifier = u2.identifier
        WHERE c.caller_identifier = ? OR c.receiver_identifier = ?
        ORDER BY c.created_at DESC
    ]], {identifier, identifier})
end

function Database.AddCall(callerIdentifier, receiverIdentifier, duration, callType, status)
    MySQL.Async.execute('INSERT INTO phone_calls (caller_identifier, receiver_identifier, duration, call_type, status) VALUES (?, ?, ?, ?, ?)', {
        callerIdentifier, receiverIdentifier, duration, callType, status
    })
end

-- Photos Management
function Database.GetPhotos(identifier)
    return MySQL.Sync.fetchAll('SELECT * FROM phone_photos WHERE owner_identifier = ? ORDER BY created_at DESC', {identifier})
end

function Database.AddPhoto(identifier, filename, url)
    MySQL.Async.execute('INSERT INTO phone_photos (owner_identifier, filename, url) VALUES (?, ?, ?)', {
        identifier, filename, url
    })
end

function Database.DeletePhoto(photoId)
    MySQL.Async.execute('DELETE FROM phone_photos WHERE id = ?', {photoId})
end

-- Notes Management
function Database.GetNotes(identifier)
    return MySQL.Sync.fetchAll('SELECT * FROM phone_notes WHERE owner_identifier = ? ORDER BY updated_at DESC', {identifier})
end

function Database.AddNote(identifier, title, content)
    MySQL.Async.execute('INSERT INTO phone_notes (owner_identifier, title, content) VALUES (?, ?, ?)', {
        identifier, title, content
    })
end

function Database.UpdateNote(noteId, title, content)
    MySQL.Async.execute('UPDATE phone_notes SET title = ?, content = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', {
        title, content, noteId
    })
end

function Database.DeleteNote(noteId)
    MySQL.Async.execute('DELETE FROM phone_notes WHERE id = ?', {noteId})
end

-- Banking Management
function Database.GetBankingData(identifier)
    return MySQL.Sync.fetchAll('SELECT * FROM phone_banking WHERE owner_identifier = ?', {identifier})
end

function Database.GetBankingTransactions(accountId)
    return MySQL.Sync.fetchAll('SELECT * FROM phone_banking_transactions WHERE account_id = ? ORDER BY created_at DESC LIMIT 50', {accountId})
end

-- Calendar Management
function Database.GetCalendarEvents(identifier)
    return MySQL.Sync.fetchAll('SELECT * FROM phone_calendar WHERE owner_identifier = ? ORDER BY start_date ASC', {identifier})
end

function Database.AddCalendarEvent(identifier, title, description, startDate, endDate, allDay)
    MySQL.Async.execute('INSERT INTO phone_calendar (owner_identifier, title, description, start_date, end_date, all_day) VALUES (?, ?, ?, ?, ?, ?)', {
        identifier, title, description, startDate, endDate, allDay
    })
end

-- Email Management
function Database.GetEmails(identifier)
    return MySQL.Sync.fetchAll('SELECT * FROM phone_emails WHERE owner_identifier = ? ORDER BY created_at DESC', {identifier})
end

function Database.AddEmail(identifier, sender, subject, body)
    MySQL.Async.execute('INSERT INTO phone_emails (owner_identifier, sender, subject, body) VALUES (?, ?, ?, ?)', {
        identifier, sender, subject, body
    })
end

function Database.MarkEmailAsRead(emailId)
    MySQL.Async.execute('UPDATE phone_emails SET read_status = TRUE WHERE id = ?', {emailId})
end

-- Initialize database on resource start
CreateThread(function()
    Database.Initialize()
end)

-- Export Database functions
_G.PhoneDatabase = Database
