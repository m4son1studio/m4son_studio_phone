local Framework = nil

-- Framework Detection
CreateThread(function()
    if Config.Framework == 'auto' then
        -- Auto-detect framework
        if GetResourceState('es_extended') == 'started' then
            Framework = 'ESX'
        elseif GetResourceState('qb-core') == 'started' then
            Framework = 'QBCore'
        else
            Framework = 'Standalone'
        end
    else
        Framework = Config.Framework:upper()
    end
    
    -- Initialize framework
    if Framework == 'ESX' then
        InitializeESX()
    elseif Framework == 'QBCORE' then
        InitializeQBCore()
    end
    
    print('^2[M4SON1 Phone]^0 Server Framework detected: ' .. Framework)
end)

-- ESX Initialization
function InitializeESX()
    ESX = exports['es_extended']:getSharedObject()
end

-- QBCore Initialization
function InitializeQBCore()
    QBCore = exports['qb-core']:GetCoreObject()
end

-- Get Player from Source
function GetPlayer(source)
    if Framework == 'ESX' then
        return ESX.GetPlayerFromId(source)
    elseif Framework == 'QBCORE' then
        return QBCore.Functions.GetPlayer(source)
    else
        return nil
    end
end

-- Get Player Identifier
function GetPlayerIdentifier(source)
    if Framework == 'ESX' then
        local xPlayer = ESX.GetPlayerFromId(source)
        return xPlayer and xPlayer.identifier or nil
    elseif Framework == 'QBCORE' then
        local Player = QBCore.Functions.GetPlayer(source)
        return Player and Player.PlayerData.citizenid or nil
    else
        return GetPlayerIdentifiers(source)[1]
    end
end

-- Get Player Money
function GetPlayerMoney(source, moneyType)
    moneyType = moneyType or 'cash'
    
    if Framework == 'ESX' then
        local xPlayer = ESX.GetPlayerFromId(source)
        return xPlayer and xPlayer.getMoney() or 0
    elseif Framework == 'QBCORE' then
        local Player = QBCore.Functions.GetPlayer(source)
        return Player and Player.PlayerData.money[moneyType] or 0
    else
        return 0
    end
end

-- Add Player Money
function AddPlayerMoney(source, amount, moneyType)
    moneyType = moneyType or 'cash'
    
    if Framework == 'ESX' then
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer then
            xPlayer.addMoney(amount)
            return true
        end
    elseif Framework == 'QBCORE' then
        local Player = QBCore.Functions.GetPlayer(source)
        if Player then
            Player.Functions.AddMoney(moneyType, amount)
            return true
        end
    end
    
    return false
end

-- Remove Player Money
function RemovePlayerMoney(source, amount, moneyType)
    moneyType = moneyType or 'cash'
    
    if Framework == 'ESX' then
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer and xPlayer.getMoney() >= amount then
            xPlayer.removeMoney(amount)
            return true
        end
    elseif Framework == 'QBCORE' then
        local Player = QBCore.Functions.GetPlayer(source)
        if Player and Player.PlayerData.money[moneyType] >= amount then
            Player.Functions.RemoveMoney(moneyType, amount)
            return true
        end
    end
    
    return false
end

-- Get Player Job
function GetPlayerJob(source)
    if Framework == 'ESX' then
        local xPlayer = ESX.GetPlayerFromId(source)
        return xPlayer and xPlayer.job or nil
    elseif Framework == 'QBCORE' then
        local Player = QBCore.Functions.GetPlayer(source)
        return Player and Player.PlayerData.job or nil
    else
        return nil
    end
end

-- Show Notification
function ShowNotification(source, message, type, duration)
    if Framework == 'ESX' then
        TriggerClientEvent('esx:showNotification', source, message, type, duration)
    elseif Framework == 'QBCORE' then
        TriggerClientEvent('QBCore:Notify', source, message, type, duration)
    else
        -- Fallback notification
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 255, 255},
            multiline = true,
            args = {'Phone', message}
        })
    end
end

-- Export functions
exports('GetFramework', function()
    return Framework
end)

exports('GetPlayer', GetPlayer)
exports('GetPlayerIdentifier', GetPlayerIdentifier)
exports('GetPlayerMoney', GetPlayerMoney)
exports('AddPlayerMoney', AddPlayerMoney)
exports('RemovePlayerMoney', RemovePlayerMoney)
exports('GetPlayerJob', GetPlayerJob)
exports('ShowNotification', ShowNotification)
