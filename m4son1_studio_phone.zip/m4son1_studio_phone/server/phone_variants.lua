-- Phone Variants and Inventory Integration
local PhoneVariants = {}

-- Initialize phone variants
function PhoneVariants.Init()
    -- Register phone variants as items (ESX/QBCore)
    if Framework == 'ESX' then
        PhoneVariants.RegisterESXItems()
    elseif Framework == 'QBCORE' then
        PhoneVariants.RegisterQBCoreItems()
    end
    
    print('^2[M4SON1 Phone]^0 Phone variants initialized')
end

-- Register ESX Items
function PhoneVariants.RegisterESXItems()
    for phoneId, phoneConfig in pairs(Config.PhoneColors) do
        ESX.RegisterUsableItem(phoneId, function(source)
            local xPlayer = ESX.GetPlayerFromId(source)
            if xPlayer then
                PhoneVariants.GivePhoneToPlayer(source, phoneId)
            end
        end)
    end
end

-- Register QBCore Items
function PhoneVariants.RegisterQBCoreItems()
    for phoneId, phoneConfig in pairs(Config.PhoneColors) do
        QBCore.Functions.CreateUseableItem(phoneId, function(source, item)
            local Player = QBCore.Functions.GetPlayer(source)
            if Player then
                PhoneVariants.GivePhoneToPlayer(source, phoneId)
            end
        end)
    end
end

-- Give phone to player
function PhoneVariants.GivePhoneToPlayer(source, phoneId)
    local identifier = exports.m4son1_studio_phone:GetPlayerIdentifier(source)
    if not identifier then return end
    
    -- Update player's phone variant in database
    MySQL.Async.execute('UPDATE phone_users SET phone_variant = ? WHERE identifier = ?', {
        phoneId, identifier
    })
    
    -- Send phone variant to client
    TriggerClientEvent('phone:client:setPhoneVariant', source, phoneId)
    
    -- Show notification
    exports.m4son1_studio_phone:ShowNotification(source, 'Phone activated: ' .. Config.PhoneColors[phoneId].name, 'success')
end

-- Get player's phone variant
function PhoneVariants.GetPlayerPhoneVariant(identifier)
    local result = MySQL.Sync.fetchAll('SELECT phone_variant FROM phone_users WHERE identifier = ?', {identifier})
    if result[1] then
        return result[1].phone_variant or 'iphone_15_pro_max_black'
    end
    return 'iphone_15_pro_max_black'
end

-- Admin command to give phone
RegisterCommand('givephone', function(source, args)
    if source == 0 then -- Console
        if args[1] and args[2] then
            local targetId = tonumber(args[1])
            local phoneId = args[2]
            
            if Config.PhoneColors[phoneId] then
                PhoneVariants.GivePhoneToPlayer(targetId, phoneId)
                print('^2[M4SON1 Phone]^0 Gave ' .. phoneId .. ' to player ' .. targetId)
            else
                print('^1[M4SON1 Phone]^0 Invalid phone ID: ' .. phoneId)
            end
        else
            print('^1[M4SON1 Phone]^0 Usage: givephone <playerid> <phone_id>')
        end
    else
        -- Check if player has admin permissions
        if Framework == 'ESX' then
            local xPlayer = ESX.GetPlayerFromId(source)
            if xPlayer and xPlayer.getGroup() == 'admin' then
                PhoneVariants.HandleAdminCommand(source, args)
            end
        elseif Framework == 'QBCORE' then
            local Player = QBCore.Functions.GetPlayer(source)
            if Player and QBCore.Functions.HasPermission(source, 'admin') then
                PhoneVariants.HandleAdminCommand(source, args)
            end
        end
    end
end)

-- Handle admin command
function PhoneVariants.HandleAdminCommand(source, args)
    if args[1] and args[2] then
        local targetId = tonumber(args[1])
        local phoneId = args[2]
        
        if Config.PhoneColors[phoneId] then
            PhoneVariants.GivePhoneToPlayer(targetId, phoneId)
            exports.m4son1_studio_phone:ShowNotification(source, 'Phone given to player ' .. targetId, 'success')
        else
            exports.m4son1_studio_phone:ShowNotification(source, 'Invalid phone ID', 'error')
        end
    else
        exports.m4son1_studio_phone:ShowNotification(source, 'Usage: /givephone <playerid> <phone_id>', 'error')
    end
end

-- Shop system for buying phones
RegisterNetEvent('phone:server:buyPhone', function(phoneId)
    local source = source
    local identifier = exports.m4son1_studio_phone:GetPlayerIdentifier(source)
    
    if not identifier or not Config.PhoneColors[phoneId] then return end
    
    local phoneConfig = Config.PhoneColors[phoneId]
    local price = phoneConfig.price
    
    -- Check if player has enough money
    local playerMoney = exports.m4son1_studio_phone:GetPlayerMoney(source, 'cash')
    
    if playerMoney >= price then
        -- Remove money
        if exports.m4son1_studio_phone:RemovePlayerMoney(source, price, 'cash') then
            -- Give phone item
            if Framework == 'ESX' then
                local xPlayer = ESX.GetPlayerFromId(source)
                if xPlayer then
                    xPlayer.addInventoryItem(phoneId, 1)
                end
            elseif Framework == 'QBCORE' then
                local Player = QBCore.Functions.GetPlayer(source)
                if Player then
                    Player.Functions.AddItem(phoneId, 1)
                end
            end
            
            exports.m4son1_studio_phone:ShowNotification(source, 'Phone purchased: ' .. phoneConfig.name, 'success')
        else
            exports.m4son1_studio_phone:ShowNotification(source, 'Transaction failed', 'error')
        end
    else
        exports.m4son1_studio_phone:ShowNotification(source, 'Not enough money', 'error')
    end
end)

-- Export functions
exports('GivePhoneToPlayer', PhoneVariants.GivePhoneToPlayer)
exports('GetPlayerPhoneVariant', PhoneVariants.GetPlayerPhoneVariant)

-- Initialize on resource start
CreateThread(function()
    Wait(1000) -- Wait for framework to load
    PhoneVariants.Init()
end)

_G.PhoneVariants = PhoneVariants