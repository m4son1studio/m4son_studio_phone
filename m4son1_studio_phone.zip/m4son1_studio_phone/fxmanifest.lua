fx_version 'cerulean'
game 'gta5'

author 'M4SON1 Studio'
description 'iPhone 15 Pro Max Style Phone System for FiveM'
version '1.0.0'

lua54 'yes'

shared_scripts {
    'config.lua'
}

client_scripts {
    'client/framework.lua',
    'client/phone_variants.lua',
    'client/main.lua'
}

server_scripts {
    'server/framework.lua',
    'server/database.lua',
    'server/phone_variants.lua',
    'server/main.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/*.css',
    'html/js/*.js',
    'html/assets/**/*',
    'sql/*.sql'
}

dependencies {
    'oxmysql'
}

provides {
    'm4son1_studio_phone'
}
